import os
import json
import asyncio
import logging
import secrets
from pathlib import Path
from datetime import datetime, timedelta
from typing import Any, Dict, Optional, List

from fastapi import FastAPI, Request, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, KeyboardButton, Bot
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, ChatMemberHandler, ContextTypes, filters
from telegram.constants import ChatMemberStatus

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
LOG = logging.getLogger("professor-server")

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
DATA_DIR.mkdir(exist_ok=True)
CONFIG_FILE = DATA_DIR / "config.json"
SUBS_FILE = DATA_DIR / "subs_data.json"
CRM_FILE = DATA_DIR / "prof_crm.json"
NOTIFICATIONS_FILE = DATA_DIR / "notifications.json"
AUTH_FILE = DATA_DIR / "server_auth.json"
API_KEY_FILE = BASE_DIR / "PROFESSOR_API_KEY.txt"

API_KEY = os.getenv("PROFESSOR_API_KEY") or os.getenv("API_KEY") or os.getenv("TOKEN_API") or ""
if not API_KEY:
    LOG.info("No environment API key found. First app can pair automatically and generate a private API key.")


def now_str() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def read_json(path: Path, default: Any) -> Any:
    if not path.exists():
        write_json(path, default)
        return json.loads(json.dumps(default, ensure_ascii=False))
    try:
        with path.open("r", encoding="utf-8") as f:
            data = json.load(f)
        return data
    except Exception as e:
        LOG.error("Failed reading %s: %s", path, e)
        backup = path.with_suffix(path.suffix + ".broken_" + datetime.now().strftime("%Y%m%d%H%M%S"))
        try:
            path.rename(backup)
        except Exception:
            pass
        write_json(path, default)
        return json.loads(json.dumps(default, ensure_ascii=False))


def write_json(path: Path, data: Any) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=4)
    tmp.replace(path)


DEFAULT_SUB_MESSAGES = {
    "user_prompt": ["اضغط على الزر أدناه للتفاعل:"],
    "welcome_admin": ["مرحبا أيها المشرف! اختر العملية:"],
    "already_subscribed": ["✅ أنت مشترك بالفعل!"],
    "busy_channel": ["⛔️ يرجى الانتظار، يوجد لديك طلب قيد المراجعة."],
    "busy_indicator": ["⛔️ يرجى الانتظار، يوجد لديك طلب قيد المراجعة."],
    "choose_subscription": ["اختر مدة الاشتراك:"],
    "choose_service_type": ["👇 يرجى اختيار نوع الخدمة التي تريد الاشتراك بها:"],
    "ask_tv_username": ["📉 يرجى كتابة اسم المستخدم الخاص بك في TradingView:"],
    "subscription_sent": ["✅ طلب الاشتراك تم إرساله، انتظر موافقة المشرف."],
    "subscription_channel_message": ["🎉 مرحبًا {name}! تم تفعيل اشتراكك في القناة.", "مدة الاشتراك: {days} أيام"],
    "subscription_indicator_message": ["🎉 مرحبًا {name}! تم تفعيل اشتراك المؤشر بنجاح.", "مدة الاشتراك: {days} أيام"],
    "tips_channel": ["⚠️ التزم بإدارة رأس المال وحجم اللوت المحدد."],
    "tips_indicator": ["تم تفعيل المؤشر بنجاح."],
    "subscription_ended_channel": ["❌ انتهى اشتراكك في القناة اليوم."],
    "subscription_ended_indicator": ["❌ انتهى اشتراكك في مؤشر TradingView اليوم."],
    "subscription_expiring_channel": ["⚠️ تنبيه: اشتراكك في القناة سينتهي غداً!"],
    "subscription_expiring_indicator": ["⚠️ تنبيه: اشتراكك في المؤشر سينتهي غداً!"],
    "reject_user_channel": ["❌ عذراً، تم رفض طلبك الخاص باشتراك القناة."],
    "reject_user_indicator": ["❌ عذراً، تم رفض طلبك الخاص بالمؤشر."],
    "subscription_request_admin": ["🟢 طلب اشتراك جديد!", "👤 الاسم: {name}", "📦 الخدمة: {service}", "{extra_info}", "📅 المدة: {days} أيام"],
    "subscription_approved_admin": ["✅ تم تفعيل خدمة ({service}) للمستخدم {name}."],
    "subscription_expiring_1day_admin": ["⚠️ قرب انتهاء الاشتراك:\nالمشترك: {name}\nالنوع: {type}"],
    "subscription_removed_admin": ["❌ تمت إزالة المشترك {name}."],
    "msg_already_processed": ["⚠️ هذا الطلب تمت معالجته مسبقاً."],
    "msg_rejected_user": ["❌ تم رفض الطلب."],
    "msg_no_subs": ["⚠️ لا يوجد مشتركين حالياً."],
    "msg_id_not_found": ["❌ الآيدي غير موجود."],
    "edit_success": ["✅ تم تحديث البيانات بنجاح!"]
}

DEFAULT_MARKETING_MESSAGES = {
    "contract_msg": "عقد الشراكة وآلية العمل (نظام المسوقين) 🤝\n\nأهلاً بك يا شريك النجاح. العمولة تُحتسب على أول اشتراك فعلي للعميل فقط، ولا تُحتسب على التجديدات.",
    "marketer_welcome": "أهلاً بك يا شريك النجاح ({name}) في اللوحة التنفيذية! 👑\n\nرابطك التسويقي:\n{link}\n\nعمولتك: {commission}",
    "new_public_lead": "👀 عميل جديد ({client}) انضم للقناة العامة عبر رابطك.",
    "new_vip_lead": "🎉 مبروك! العميل ({client}) اشترك فعلياً في VIP وتمت إضافته لرصيدك.",
    "commission_paid": "💸 تم قبول طلبك وتحويل عمولة العميل ({client}) لك.",
    "withdrawal_rejected": "❌ تم رفض طلب سحب الأرباح للعميل ({client}).",
    "join_rejected": "❌ عذراً، تم رفض طلب انضمامك كمسوق.",
    "link_updated": "⚠️ رابطك التسويقي الجديد:\n{link}"
}

DEFAULT_CONFIG = {
    "configured": False,
    "brand_name": "",
    "admin_id": "",
    "support_url": "",
    "subscription_bot_token": "",
    "marketing_bot_token": "",
    "subscription_vip_channel_id": "",
    "marketing_vip_channel_id": "",
    "public_channel_id": "",
    "channel_link": "",
    "indicator_link": "",
    "default_subscription_days": 7,
    "channel_durations": ["30 يوم", "90 يوم", "365 يوم"],
    "indicator_durations": ["30 يوم", "90 يوم", "365 يوم"],
    "default_commission": "غير محددة",
    "subscription_messages": DEFAULT_SUB_MESSAGES,
    "marketing_messages": DEFAULT_MARKETING_MESSAGES,
}
DEFAULT_SUBS = {"pending_subs": {}, "active_subs": {}, "stats": {"total_revenue": 0.0, "total_subscribers": 0}}
DEFAULT_CRM = {"whitelist": {}, "referrals": {}, "active_links": {}, "paid_count": 0, "total_joined": 0, "marketers_data": {}, "public_leads": {}, "pending_requests": {}, "historical_clients": {}, "withdrawal_requests": {}}
DEFAULT_NOTIFICATIONS = {"items": []}


def cfg() -> Dict[str, Any]:
    data = read_json(CONFIG_FILE, DEFAULT_CONFIG)
    changed = False
    for k, v in DEFAULT_CONFIG.items():
        if k not in data:
            data[k] = v
            changed = True
    if changed:
        write_json(CONFIG_FILE, data)
    return data


def save_cfg(data: Dict[str, Any]) -> None:
    write_json(CONFIG_FILE, data)


def subs() -> Dict[str, Any]:
    return read_json(SUBS_FILE, DEFAULT_SUBS)


def save_subs(data: Dict[str, Any]) -> None:
    write_json(SUBS_FILE, data)


def crm() -> Dict[str, Any]:
    data = read_json(CRM_FILE, DEFAULT_CRM)
    for k, v in DEFAULT_CRM.items():
        data.setdefault(k, v)
    return data


def save_crm(data: Dict[str, Any]) -> None:
    write_json(CRM_FILE, data)


def notifications() -> Dict[str, Any]:
    return read_json(NOTIFICATIONS_FILE, DEFAULT_NOTIFICATIONS)


def save_notifications(data: Dict[str, Any]) -> None:
    # احتفظ بآخر 500 إشعار فقط حتى لا يكبر الملف كثيراً
    data["items"] = list(data.get("items", []))[-500:]
    write_json(NOTIFICATIONS_FILE, data)


def notify(ntype: str, title: str, message: str, extra: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    data = notifications()
    items = data.setdefault("items", [])
    next_id = (max([int(x.get("id", 0)) for x in items], default=0) + 1) if items else 1
    item = {"id": next_id, "type": ntype, "title": title, "message": message, "date": now_str(), "read": False}
    if extra: item["extra"] = extra
    items.append(item)
    save_notifications(data)
    return item


def msg_text(key: str, fallback: str = "") -> str:
    value = cfg().get("subscription_messages", {}).get(key, [fallback])
    if isinstance(value, list):
        return "\n".join(str(x) for x in value)
    return str(value)


def mkmsg(key: str, fallback: str = "") -> str:
    return str(cfg().get("marketing_messages", {}).get(key, fallback))


def admin_id() -> Optional[int]:
    v = str(cfg().get("admin_id", "")).strip()
    return int(v) if v.lstrip("-").isdigit() else None


def channel_id_value(key: str) -> Optional[int]:
    v = str(cfg().get(key, "")).strip()
    return int(v) if v.lstrip("-").isdigit() else None


def auth_data() -> Dict[str, Any]:
    if API_KEY:
        return {"api_key": API_KEY, "source": "environment", "paired": True}
    if AUTH_FILE.exists():
        return read_json(AUTH_FILE, {"api_key": "", "source": "file", "paired": False})
    return {"api_key": "", "source": "none", "paired": False}


def current_api_key() -> str:
    return str(auth_data().get("api_key", "")).strip()


def create_first_pairing(client_id: str = "") -> Dict[str, Any]:
    if API_KEY:
        return {"ok": False, "already_paired": True, "env_locked": True, "message": "Server uses environment API key."}
    existing = auth_data()
    if existing.get("api_key"):
        return {"ok": False, "already_paired": True, "env_locked": False, "message": "Server already paired."}
    key = "prof_" + secrets.token_urlsafe(32)
    data = {"api_key": key, "paired": True, "source": "auto_pair", "client_id": client_id or "", "created_at": now_str()}
    write_json(AUTH_FILE, data)
    try:
        API_KEY_FILE.write_text(
            "PROFESSOR ECOSYSTEM API KEY\n"
            "================================\n\n"
            "احفظ هذا المفتاح في مكان آمن. إذا حذفت تطبيق PROFESSOR أو غيرت الهاتف ستحتاج هذا المفتاح لإعادة ربط التطبيق بنفس السيرفر.\n\n"
            f"API_KEY={key}\n\n"
            "طريقة إعادة الربط من التطبيق:\n"
            "1) افتح إدارة منظومة المشتركين والمسوقين.\n"
            "2) أدخل رابط السيرفر.\n"
            "3) ضع هذا المفتاح في خانة API Key.\n\n"
            "تنبيه: لا تشارك هذا المفتاح إلا مع مالك السيرفر أو المدير الموثوق.\n",
            encoding="utf-8"
        )
    except Exception:
        pass
    notify("server_pairing", "تم ربط السيرفر", "تم إنشاء مفتاح API تلقائياً لأول جهاز ربط السيرفر. احفظ المفتاح من التطبيق أو من ملف PROFESSOR_API_KEY.txt.", {"client_id": client_id or ""})
    return {"ok": True, "api_key": key, "paired": True, "client_id": client_id or "", "warning": "احفظ مفتاح API الآن. إذا حذفت التطبيق ستحتاجه لإعادة الربط."}


def require_api(request: Request) -> None:
    key = current_api_key()
    if not key:
        raise HTTPException(status_code=401, detail="Server is not paired yet. Use /api/pair/claim from the app.")
    provided = request.headers.get("X-API-Key") or request.headers.get("Authorization", "").replace("Bearer ", "")
    if provided != key:
        raise HTTPException(status_code=401, detail="Invalid API key")


app = FastAPI(title="PROFESSOR Ecosystem API", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=False, allow_methods=["*"], allow_headers=["*"])


@app.middleware("http")
async def auth_middleware(request: Request, call_next):
    public_paths = {"/api/health", "/api/pair/status", "/api/pair/claim"}
    if request.url.path.startswith("/api/") and request.url.path not in public_paths:
        require_api(request)
    return await call_next(request)


async def safe_send(application: Optional[Application], chat_id: Any, text: str, **kwargs):
    if not application or not chat_id:
        return False
    try:
        await application.bot.send_message(chat_id=int(chat_id), text=text, **kwargs)
        return True
    except Exception as e:
        LOG.warning("send failed to %s: %s", chat_id, e)
        return False


class BotRuntime:
    def __init__(self):
        self.apps: List[Application] = []
        self.sub_app: Optional[Application] = None
        self.marketing_app: Optional[Application] = None
        self.checker_task: Optional[asyncio.Task] = None

    async def start(self):
        c = cfg()
        sub_token = c.get("subscription_bot_token", "").strip()
        m_token = c.get("marketing_bot_token", "").strip()
        tokens = []
        if sub_token:
            tokens.append(("sub", sub_token))
        if m_token and m_token != sub_token:
            tokens.append(("marketing", m_token))
        elif m_token and m_token == sub_token:
            tokens = [("both", sub_token)]
        for kind, token in tokens:
            application = Application.builder().token(token).build()
            self.add_handlers(application, kind)
            await application.initialize()
            await application.start()
            await application.updater.start_polling(allowed_updates=Update.ALL_TYPES)
            self.apps.append(application)
            if kind in ("sub", "both"):
                self.sub_app = application
            if kind in ("marketing", "both"):
                self.marketing_app = application
            LOG.info("Started Telegram runtime: %s", kind)
        self.checker_task = asyncio.create_task(self.checker_loop())

    async def stop(self):
        if self.checker_task:
            self.checker_task.cancel()
            try:
                await self.checker_task
            except BaseException:
                pass
        for application in list(self.apps):
            try:
                await application.updater.stop()
                await application.stop()
                await application.shutdown()
            except Exception as e:
                LOG.warning("bot stop failed: %s", e)
        self.apps.clear()
        self.sub_app = None
        self.marketing_app = None

    async def restart(self):
        await self.stop()
        await self.start()

    def add_handlers(self, application: Application, kind: str):
        application.add_handler(CommandHandler("start", self.start_handler))
        application.add_handler(CallbackQueryHandler(self.callback_handler))
        application.add_handler(ChatMemberHandler(self.track_joins, ChatMemberHandler.CHAT_MEMBER))
        application.add_handler(MessageHandler(filters.ALL & ~filters.COMMAND, self.message_handler))

    async def start_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        user_id = str(update.effective_user.id)
        c = cfg()
        d = crm()
        buttons = []
        if user_id == str(c.get("admin_id")):
            buttons = [["📢 لوحة الإدارة"], ["📋 قائمة المشتركين", "📊 إحصائيات عامة"]]
        elif user_id in d.get("whitelist", {}):
            buttons = [["💰 رصيدي الحالي", "🔗 رابطي التسويقي"], ["💸 طلب سحب الأرباح"]]
        else:
            buttons = [["اشتراك"], ["🤝 طلب الانضمام كمسوق"]]
        support = c.get("support_url")
        if support:
            buttons.append(["🗣 خدمة العملاء"])
        await update.message.reply_text(msg_text("user_prompt", "اختر من القائمة:"), reply_markup=ReplyKeyboardMarkup(buttons, resize_keyboard=True))

    async def message_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        if not update.message:
            return
        user_id = str(update.effective_user.id)
        text = update.message.text or update.message.caption or ""
        c = cfg()
        if text == "🗣 خدمة العملاء" and c.get("support_url"):
            await update.message.reply_text("تفضل بالتواصل معنا:", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("الدعم", url=c["support_url"])]]) )
            return
        if user_id == str(c.get("admin_id")):
            await self.admin_message(update, context, text)
            return
        d = crm()
        if user_id in d.get("whitelist", {}):
            await self.marketer_message(update, context, text)
            return
        await self.user_subscription_message(update, context, text)

    async def admin_message(self, update, context, text):
        if text == "📋 قائمة المشتركين":
            s = subs().get("active_subs", {})
            body = "\n".join([f"{v.get('name','-')} | {uid}" for uid, v in s.items()]) or "لا يوجد مشتركين."
            await update.message.reply_text(body[:3500])
        elif text == "📊 إحصائيات عامة":
            await update.message.reply_text(json.dumps(api_stats(), ensure_ascii=False, indent=2)[:3500])
        else:
            await update.message.reply_text("استخدم تطبيق PROFESSOR لإدارة المنظومة بالكامل.")

    async def user_subscription_message(self, update, context, text):
        user_id = str(update.effective_user.id)
        c = cfg()
        st = context.user_data.get("sub_step")
        durations_ch = c.get("channel_durations", [])
        durations_ind = c.get("indicator_durations", [])
        if text == "اشتراك":
            context.user_data["sub_step"] = "service"
            await update.message.reply_text(msg_text("choose_service_type"), reply_markup=ReplyKeyboardMarkup([["📢 قناة تليجرام", "📉 مؤشر TradingView"]], resize_keyboard=True))
            return
        if text == "🤝 طلب الانضمام كمسوق":
            d = crm(); d.setdefault("pending_requests", {})[user_id] = {"name": update.effective_user.full_name, "username": update.effective_user.username or "", "date": now_str()}; save_crm(d)
            notify("marketer_request", "طلب مسوق جديد", f"{update.effective_user.full_name} أرسل طلب انضمام كمسوق", {"user_id": user_id})
            await update.message.reply_text("✅ تم إرسال طلبك للإدارة.")
            aid = admin_id()
            if aid:
                kb = [[InlineKeyboardButton("✅ قبول", callback_data=f"mk_accept_{user_id}"), InlineKeyboardButton("❌ رفض", callback_data=f"mk_reject_{user_id}")]]
                await safe_send(self.marketing_app or self.sub_app, aid, f"طلب مسوق جديد:\n{update.effective_user.full_name}\nID: {user_id}", reply_markup=InlineKeyboardMarkup(kb))
            return
        if st == "service":
            if "مؤشر" in text:
                context.user_data["service"] = "indicator"; context.user_data["sub_step"] = "tv"
                await update.message.reply_text(msg_text("ask_tv_username"))
            else:
                context.user_data["service"] = "channel"; context.user_data["sub_step"] = "duration"
                await update.message.reply_text(msg_text("choose_subscription"), reply_markup=ReplyKeyboardMarkup([durations_ch], resize_keyboard=True))
            return
        if st == "tv":
            context.user_data["tv_user"] = text; context.user_data["sub_step"] = "duration"
            await update.message.reply_text(msg_text("choose_subscription"), reply_markup=ReplyKeyboardMarkup([durations_ind], resize_keyboard=True))
            return
        if st == "duration":
            days = parse_days(text) or int(c.get("default_subscription_days", 7))
            service = context.user_data.get("service", "channel")
            s = subs(); s.setdefault("pending_subs", {})[user_id] = {"name": update.effective_user.full_name, "days": days, "added_service": service, "tv_user": context.user_data.get("tv_user", ""), "date": now_str()}; save_subs(s)
            notify("subscription_request", "طلب اشتراك جديد", f"{update.effective_user.full_name} طلب اشتراك {service} لمدة {days} يوم", {"user_id": user_id, "service": service})
            context.user_data.clear()
            await update.message.reply_text(msg_text("subscription_sent"))
            aid = admin_id()
            if aid:
                kb = [[InlineKeyboardButton("✅ قبول", callback_data=f"sub_accept_{user_id}"), InlineKeyboardButton("❌ رفض", callback_data=f"sub_reject_{user_id}")]]
                await safe_send(self.sub_app or self.marketing_app, aid, f"طلب اشتراك جديد\n{update.effective_user.full_name}\nالخدمة: {service}\nالمدة: {days} يوم", reply_markup=InlineKeyboardMarkup(kb))
            return

    async def marketer_message(self, update, context, text):
        user_id = str(update.effective_user.id); d = crm(); name = d["whitelist"].get(user_id)
        if text == "🔗 رابطي التسويقي":
            await update.message.reply_text(d.get("active_links", {}).get(name, "لا يوجد رابط نشط."))
        elif text == "💰 رصيدي الحالي":
            pending = len(d.get("referrals", {}).get(name, [])); total = d.get("marketers_data", {}).get(user_id, {}).get("total_brought", 0); comm = d.get("marketers_data", {}).get(user_id, {}).get("commission", "غير محددة")
            await update.message.reply_text(f"💰 العمولة: {comm}\n⏳ عملاء مستحقين: {pending}\n👥 إجمالي العملاء: {total}")
        elif text == "💸 طلب سحب الأرباح":
            d.setdefault("withdrawal_requests", {})[user_id] = {"name": name, "date": now_str(), "clients": d.get("referrals", {}).get(name, [])}; save_crm(d)
            notify("withdrawal_request", "طلب سحب أرباح", f"المسوق {name} أرسل طلب سحب أرباح", {"user_id": user_id})
            await update.message.reply_text("✅ تم إرسال طلب السحب للإدارة.")
        else:
            await update.message.reply_text("اختر من القائمة.")

    async def callback_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        q = update.callback_query
        if not q: return
        await q.answer()
        data = q.data or ""
        if data.startswith("sub_accept_"):
            uid = data.split("_", 2)[2]
            result = await approve_subscriber(uid, 0, self.sub_app or self.marketing_app)
            await q.edit_message_text("✅ تم قبول الاشتراك" if result else "⚠️ الطلب غير موجود")
        elif data.startswith("sub_reject_"):
            uid = data.split("_", 2)[2]
            await reject_subscriber(uid, self.sub_app or self.marketing_app)
            await q.edit_message_text("❌ تم رفض الطلب")
        elif data.startswith("mk_accept_"):
            uid = data.split("_", 2)[2]
            await approve_marketer(uid, None, cfg().get("default_commission", "غير محددة"), self.marketing_app or self.sub_app)
            await q.edit_message_text("✅ تم قبول المسوق")
        elif data.startswith("mk_reject_"):
            uid = data.split("_", 2)[2]
            await reject_marketer(uid, self.marketing_app or self.sub_app)
            await q.edit_message_text("❌ تم رفض المسوق")

    async def track_joins(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        if not update.chat_member: return
        res = update.chat_member
        if res.new_chat_member.status != ChatMemberStatus.MEMBER or res.old_chat_member.status == ChatMemberStatus.MEMBER:
            return
        c = cfg(); d = crm(); user = res.new_chat_member.user; chat_id = update.effective_chat.id
        info = {"id": user.id, "n": user.full_name, "d": datetime.now().strftime("%Y-%m-%d %H:%M"), "username": user.username or "لا يوجد"}
        public_id = channel_id_value("public_channel_id")
        vip_id = channel_id_value("marketing_vip_channel_id") or channel_id_value("subscription_vip_channel_id")
        if public_id and chat_id == public_id and res.invite_link and res.invite_link.name:
            m_name = res.invite_link.name.lower(); uid = str(user.id)
            if uid not in d.get("historical_clients", {}):
                d.setdefault("public_leads", {}).setdefault(m_name, []).append(info); d.setdefault("historical_clients", {})[uid] = m_name; save_crm(d); notify("public_join", "عميل دخل القناة العامة", f"{user.full_name} دخل عبر رابط {m_name}", {"user_id": uid, "marketer": m_name})
        elif vip_id and chat_id == vip_id:
            found = None; lead = None
            for m, leads in d.get("public_leads", {}).items():
                for i, l in enumerate(leads):
                    if l.get("id") == user.id:
                        found = m; lead = l; del leads[i]; break
                if found: break
            if found and lead:
                d.setdefault("referrals", {}).setdefault(found, []).append(lead); d["total_joined"] = d.get("total_joined", 0) + 1
                mid = next((uid for uid, n in d.get("whitelist", {}).items() if n == found), None)
                if mid: d.setdefault("marketers_data", {}).setdefault(mid, {})["total_brought"] = d.get("marketers_data", {}).get(mid, {}).get("total_brought", 0) + 1
                save_crm(d)
                notify("vip_join", "اشتراك VIP فعلي", f"{user.full_name} اشترك فعلياً عبر المسوق {found}", {"user_id": str(user.id), "marketer": found})

    async def checker_loop(self):
        while True:
            try:
                await asyncio.sleep(60)
                data = subs(); active = data.get("active_subs", {}); changed = False
                now = datetime.now()
                for uid, info in list(active.items()):
                    for service, key, msg_key in [("channel", "channel_end", "subscription_ended_channel"), ("indicator", "indicator_end", "subscription_ended_indicator")]:
                        if key in info:
                            try:
                                end = datetime.strptime(info[key], "%Y-%m-%d %H:%M:%S")
                                if (end - now).total_seconds() <= 0:
                                    await safe_send(self.sub_app or self.marketing_app, uid, msg_text(msg_key))
                                    notify("subscription_expired", "انتهاء اشتراك", f"انتهى اشتراك {info.get('name', uid)} في {service}", {"user_id": uid, "service": service})
                                    del info[key]; changed = True
                            except Exception:
                                pass
                    if "channel_end" not in info and "indicator_end" not in info:
                        active.pop(uid, None); changed = True
                if changed: save_subs(data)
            except asyncio.CancelledError:
                return
            except Exception as e:
                LOG.warning("checker loop error: %s", e)


runtime = BotRuntime()


def parse_days(text: str) -> Optional[int]:
    import re
    m = re.search(r"\d+", str(text))
    return int(m.group()) if m else None


def api_stats():
    s = subs(); d = crm()
    return {"active_subscribers": len(s.get("active_subs", {})), "pending_subscribers": len(s.get("pending_subs", {})), "marketers": len(d.get("whitelist", {})), "pending_marketers": len(d.get("pending_requests", {})), "pending_clients": sum(len(v) for v in d.get("referrals", {}).values()), "public_leads": sum(len(v) for v in d.get("public_leads", {}).values())}


@app.on_event("startup")
async def startup():
    await runtime.start()


@app.on_event("shutdown")
async def shutdown():
    await runtime.stop()


@app.get("/api/health")
async def health():
    c = cfg()
    return {"ok": True, "configured": bool(c.get("configured")), "paired": bool(current_api_key()), "brand_name": c.get("brand_name", ""), "time": now_str()}


@app.get("/api/notifications")
async def api_notifications(after: int = 0):
    items = [x for x in notifications().get("items", []) if int(x.get("id", 0)) > int(after or 0)]
    return {"rows": items[-100:]}

@app.post("/api/notifications/read")
async def api_notifications_read(payload: Dict[str, Any]):
    data = notifications(); ids = set(str(x) for x in payload.get("ids", [])); all_flag = bool(payload.get("all"))
    for item in data.get("items", []):
        if all_flag or str(item.get("id")) in ids:
            item["read"] = True
    save_notifications(data)
    return {"ok": True}

@app.get("/api/server/status")
async def api_server_status():
    c = cfg()
    return {
        "ok": True,
        "configured": bool(c.get("configured")),
        "brand_name": c.get("brand_name", ""),
        "subscription_bot_running": runtime.sub_app is not None,
        "marketing_bot_running": runtime.marketing_app is not None,
        "same_bot_token": bool(c.get("subscription_bot_token")) and c.get("subscription_bot_token") == c.get("marketing_bot_token"),
        "active_runtime_count": len(runtime.apps),
        "stats": api_stats(),
        "time": now_str()
    }

@app.post("/api/server/restart")
async def api_server_restart():
    asyncio.create_task(runtime.restart())
    notify("server", "إعادة تشغيل المنظومة", "تم إرسال أمر إعادة تشغيل بوتات السيرفر من التطبيق.")
    return {"ok": True}

@app.get("/api/backup/export")
async def api_backup_export():
    return {"config": cfg(), "subs": subs(), "crm": crm(), "notifications": notifications(), "exported_at": now_str()}

@app.get("/api/pair/status")
async def pair_status():
    a = auth_data()
    return {"ok": True, "paired": bool(a.get("api_key")), "source": a.get("source", "none"), "env_locked": bool(API_KEY), "configured": bool(cfg().get("configured"))}

@app.post("/api/pair/claim")
async def pair_claim(payload: Dict[str, Any]):
    result = create_first_pairing(str(payload.get("client_id", "")))
    if not result.get("ok"):
        raise HTTPException(status_code=409, detail=result.get("message", "Server already paired"))
    return result

@app.get("/api/setup/status")
async def setup_status():
    c = cfg(); missing = []
    for key in ["admin_id", "subscription_bot_token", "marketing_bot_token", "subscription_vip_channel_id", "public_channel_id"]:
        if not str(c.get(key, "")).strip(): missing.append(key)
    return {"configured": bool(c.get("configured")) and not missing, "missing": missing}


@app.get("/api/setup/config")
async def setup_config():
    c = cfg().copy()
    return c


@app.post("/api/setup/save")
async def setup_save(payload: Dict[str, Any]):
    c = cfg()
    for key in ["brand_name", "admin_id", "support_url", "subscription_bot_token", "marketing_bot_token", "subscription_vip_channel_id", "marketing_vip_channel_id", "public_channel_id", "channel_link", "indicator_link", "default_subscription_days", "channel_durations", "indicator_durations", "default_commission", "subscription_messages", "marketing_messages"]:
        if key in payload: c[key] = payload[key]
    c["configured"] = True
    save_cfg(c)
    await runtime.restart()
    return {"ok": True, "configured": True}


async def test_bot_token(token: str, channel_id: Any = None):
    if not token:
        return {"ok": False, "error": "token_empty"}
    try:
        bot = Bot(token=token)
        me = await bot.get_me()
        out = {"ok": True, "username": me.username, "id": me.id}
        if channel_id:
            try:
                chat = await bot.get_chat(int(channel_id))
                out["channel_ok"] = True
                out["channel_title"] = chat.title
            except Exception as e:
                out["channel_ok"] = False
                out["channel_error"] = str(e)
        return out
    except Exception as e:
        return {"ok": False, "error": str(e)}

@app.post("/api/setup/test-bots")
async def setup_test_bots(payload: Dict[str, Any]):
    sub_token = payload.get("subscription_bot_token", "")
    m_token = payload.get("marketing_bot_token", "")
    sub_vip = payload.get("subscription_vip_channel_id")
    public_id = payload.get("public_channel_id")
    m_vip = payload.get("marketing_vip_channel_id") or sub_vip
    result = {
        "subscription_bot": await test_bot_token(sub_token, sub_vip),
        "marketing_bot": await test_bot_token(m_token, public_id),
        "marketing_vip_channel": await test_bot_token(m_token, m_vip) if m_token and m_vip else {"ok": False, "error": "missing_token_or_channel"},
        "same_token": sub_token == m_token,
        "same_vip_channel": str(sub_vip) == str(m_vip),
    }
    result["ok"] = bool(result["subscription_bot"].get("ok")) and bool(result["marketing_bot"].get("ok"))
    return result


@app.get("/api/subscribers/stats")
async def subscribers_stats(): return api_stats()

@app.get("/api/subscribers")
async def subscribers_list(): return {"rows": [{"id": uid, **info} for uid, info in subs().get("active_subs", {}).items()]}

@app.get("/api/subscribers/pending")
async def subscribers_pending(): return {"rows": [{"id": uid, **info} for uid, info in subs().get("pending_subs", {}).items()]}

@app.get("/api/subscribers/expiring")
async def subscribers_expiring():
    rows=[]; now=datetime.now()
    for uid, info in subs().get("active_subs", {}).items():
        for key in ["channel_end", "indicator_end"]:
            if key in info:
                try:
                    rem=(datetime.strptime(info[key], "%Y-%m-%d %H:%M:%S")-now).days
                    if rem <= 3: rows.append({"id": uid, "service": key, "remaining_days": rem, **info})
                except: pass
    return {"rows": rows}

@app.get("/api/subscribers/remaining")
async def subscriber_remaining(user_id: str):
    info = subs().get("active_subs", {}).get(str(user_id), {})
    out = {"user_id": user_id, "name": info.get("name", "")}
    now = datetime.now()
    for key in ["channel_end", "indicator_end"]:
        if key in info:
            try: out[key+"_days"] = max(0, (datetime.strptime(info[key], "%Y-%m-%d %H:%M:%S")-now).days)
            except: pass
    return out

async def approve_subscriber(uid: str, amount: float = 0, app_obj: Optional[Application] = None):
    data = subs(); pending = data.get("pending_subs", {})
    if uid not in pending: return False
    req = pending.pop(uid); active = data.setdefault("active_subs", {})
    active.setdefault(uid, {"name": req.get("name", uid), "tv_user": req.get("tv_user", ""), "notified_1day": {}})
    end = (datetime.now()+timedelta(days=int(req.get("days", 7)))).strftime("%Y-%m-%d %H:%M:%S")
    service = req.get("added_service", "channel")
    if service == "indicator": active[uid]["indicator_end"] = end
    else: active[uid]["channel_end"] = end
    data.setdefault("stats", {})["total_revenue"] = float(data.get("stats", {}).get("total_revenue", 0)) + float(amount or 0)
    data["stats"]["total_subscribers"] = int(data["stats"].get("total_subscribers", 0)) + 1
    save_subs(data)
    notify("subscription_approved", "قبول اشتراك", f"تم قبول اشتراك {req.get('name', uid)} في خدمة {service}", {"user_id": uid, "service": service})
    await safe_send(app_obj, uid, (msg_text("subscription_indicator_message") if service=="indicator" else msg_text("subscription_channel_message")).format(name=req.get("name", uid), days=req.get("days", 7)))
    return True

async def reject_subscriber(uid: str, app_obj: Optional[Application] = None):
    data = subs(); req = data.get("pending_subs", {}).pop(uid, None); save_subs(data)
    if req:
        notify("subscription_rejected", "رفض اشتراك", f"تم رفض طلب اشتراك {req.get('name', uid)}", {"user_id": uid})
        await safe_send(app_obj, uid, msg_text("reject_user_indicator") if req.get("added_service") == "indicator" else msg_text("reject_user_channel"))
    return True

@app.post("/api/subscribers/approve")
async def api_sub_approve(payload: Dict[str, Any]): return {"ok": await approve_subscriber(str(payload.get("user_id")), float(payload.get("amount") or 0), runtime.sub_app or runtime.marketing_app)}
@app.post("/api/subscribers/reject")
async def api_sub_reject(payload: Dict[str, Any]): return {"ok": await reject_subscriber(str(payload.get("user_id")), runtime.sub_app or runtime.marketing_app)}
@app.post("/api/subscribers/add")
async def api_sub_add(payload: Dict[str, Any]):
    uid=str(payload.get("user_id")); days=int(payload.get("days") or cfg().get("default_subscription_days",7)); service=payload.get("service","channel")
    data=subs(); active=data.setdefault("active_subs",{}); active.setdefault(uid,{"name":payload.get("name",uid),"tv_user":payload.get("tv_user",""),"notified_1day":{}}); active[uid]["indicator_end" if service=="indicator" else "channel_end"]=(datetime.now()+timedelta(days=days)).strftime("%Y-%m-%d %H:%M:%S"); save_subs(data); return {"ok":True}
@app.post("/api/subscribers/delete")
async def api_sub_delete(payload: Dict[str, Any]):
    uid=str(payload.get("user_id")); service=payload.get("service","all"); data=subs(); info=data.get("active_subs",{}).get(uid)
    if info:
        if service in ("all","channel"): info.pop("channel_end",None)
        if service in ("all","indicator"): info.pop("indicator_end",None)
        if "channel_end" not in info and "indicator_end" not in info: data["active_subs"].pop(uid,None)
        save_subs(data)
    return {"ok":True}
@app.post("/api/subscribers/extend")
async def api_sub_extend(payload: Dict[str, Any]):
    uid=str(payload.get("user_id")); days=int(payload.get("days") or 0); service=payload.get("service","channel"); data=subs(); info=data.setdefault("active_subs",{}).setdefault(uid,{"name":uid,"notified_1day":{}}); key="indicator_end" if service=="indicator" else "channel_end"; base=datetime.now()
    if key in info:
        try: base=max(base, datetime.strptime(info[key], "%Y-%m-%d %H:%M:%S"))
        except: pass
    info[key]=(base+timedelta(days=days)).strftime("%Y-%m-%d %H:%M:%S"); save_subs(data); return {"ok":True}
@app.post("/api/subscribers/broadcast")
async def api_sub_broadcast(payload: Dict[str, Any]):
    target=payload.get("target","all"); text=payload.get("message",""); count=0
    for uid, info in subs().get("active_subs",{}).items():
        if target=="all" or (target=="channel" and "channel_end" in info) or (target=="indicator" and "indicator_end" in info):
            if await safe_send(runtime.sub_app or runtime.marketing_app, uid, text): count+=1
    return {"ok":True,"sent":count}
@app.post("/api/subscribers/messages/update")
async def api_sub_msg(payload: Dict[str, Any]):
    c=cfg(); c.setdefault("subscription_messages",{})[payload.get("key")]=str(payload.get("message","")).split("\n"); save_cfg(c); return {"ok":True}
@app.post("/api/subscribers/settings/update")
async def api_sub_setting(payload: Dict[str, Any]):
    c=cfg(); c[payload.get("key")]=payload.get("value",""); save_cfg(c); return {"ok":True}
@app.post("/api/subscribers/durations/{mode}")
async def api_sub_duration(mode: str, payload: Dict[str, Any]):
    c=cfg(); key="indicator_durations" if payload.get("target")=="indicator" else "channel_durations"; arr=list(c.get(key,[]))
    if mode=="add" and payload.get("duration") not in arr: arr.append(payload.get("duration"))
    if mode=="delete": arr=[x for x in arr if x != payload.get("duration")]
    if mode=="edit" and payload.get("old_duration") in arr: arr[arr.index(payload.get("old_duration"))]=payload.get("new_duration")
    c[key]=[x for x in arr if x]; save_cfg(c); return {"ok":True,"durations":c[key]}

@app.get("/api/marketers/stats")
async def marketers_stats(): return api_stats()
@app.get("/api/marketers")
async def marketers_list():
    d=crm(); return {"rows":[{"id":uid, **d.get("marketers_data",{}).get(uid,{"name":name}), "link": d.get("active_links",{}).get(name,"")} for uid,name in d.get("whitelist",{}).items()]}
@app.get("/api/marketers/pending")
async def marketers_pending(): return {"rows":[{"id":uid, **info} for uid, info in crm().get("pending_requests",{}).items()]}
@app.get("/api/marketers/pending-clients")
async def marketers_pending_clients():
    rows=[]
    for m, clients in crm().get("referrals",{}).items():
        rows += [{"marketer":m, **c} for c in clients]
    return {"rows":rows}
@app.get("/api/marketers/withdrawals")
async def marketers_withdrawals(): return {"rows":[{"id":uid, **info} for uid,info in crm().get("withdrawal_requests",{}).items()]}
@app.get("/api/marketers/info")
async def marketer_info(user_id: str):
    d=crm(); name=d.get("whitelist",{}).get(str(user_id)); return {"id":user_id,"name":name,"link":d.get("active_links",{}).get(name,""),**d.get("marketers_data",{}).get(str(user_id),{})}
@app.get("/api/marketers/balance")
async def marketer_balance(user_id: str):
    d=crm(); name=d.get("whitelist",{}).get(str(user_id)); return {"user_id":user_id,"name":name,"pending_vip":len(d.get("referrals",{}).get(name,[])),"public_leads":len(d.get("public_leads",{}).get(name,[])),"commission":d.get("marketers_data",{}).get(str(user_id),{}).get("commission","غير محددة")}
@app.get("/api/marketers/link")
async def marketer_link(user_id: str):
    d=crm(); name=d.get("whitelist",{}).get(str(user_id)); return {"user_id":user_id,"name":name,"link":d.get("active_links",{}).get(name,"")}

async def approve_marketer(uid: str, name: Optional[str], commission: str, app_obj: Optional[Application]):
    d=crm(); req=d.get("pending_requests",{}).pop(str(uid),{})
    name=(name or req.get("name") or str(uid)).lower().strip(); d.setdefault("whitelist",{})[str(uid)]=name; d.setdefault("referrals",{}).setdefault(name,[]); d.setdefault("marketers_data",{})[str(uid)]={"name":name,"commission":commission,"join_date":datetime.now().strftime("%Y-%m-%d"),"total_brought":0}
    link=""
    public_id=channel_id_value("public_channel_id")
    if app_obj and public_id:
        try:
            obj=await app_obj.bot.create_chat_invite_link(chat_id=public_id, name=name)
            link=obj.invite_link; d.setdefault("active_links",{})[name]=link
        except Exception as e: LOG.warning("create link failed: %s", e)
    save_crm(d)
    notify("marketer_approved", "قبول مسوق", f"تم قبول المسوق {name}", {"user_id": uid, "link": link})
    if link: await safe_send(app_obj, uid, mkmsg("marketer_welcome").format(name=name, link=link, commission=commission))
    return True
async def reject_marketer(uid: str, app_obj: Optional[Application]):
    d=crm(); req=d.get("pending_requests",{}).pop(str(uid),None); save_crm(d); notify("marketer_rejected", "رفض مسوق", f"تم رفض طلب المسوق {uid}", {"user_id": uid}); await safe_send(app_obj, uid, mkmsg("join_rejected")); return True
@app.post("/api/marketers/approve")
async def api_m_approve(payload: Dict[str, Any]): return {"ok": await approve_marketer(str(payload.get("user_id")), payload.get("name"), payload.get("commission") or cfg().get("default_commission","غير محددة"), runtime.marketing_app or runtime.sub_app)}
@app.post("/api/marketers/reject")
async def api_m_reject(payload: Dict[str, Any]): return {"ok": await reject_marketer(str(payload.get("user_id")), runtime.marketing_app or runtime.sub_app)}
@app.post("/api/marketers/commission")
async def api_m_comm(payload: Dict[str, Any]):
    d=crm(); uid=str(payload.get("user_id")); d.setdefault("marketers_data",{}).setdefault(uid,{})["commission"]=payload.get("commission",""); save_crm(d); return {"ok":True}
@app.post("/api/marketers/check-client")
async def api_m_check(payload: Dict[str, Any]):
    q=str(payload.get("query","")).lower(); d=crm(); found=[]
    for m, cols in {"referrals":d.get("referrals",{}),"public_leads":d.get("public_leads",{})}.items():
        for marketer, clients in cols.items():
            for c in clients:
                if q in str(c.get("id","")).lower() or q in str(c.get("username","")).lower() or q in str(c.get("n","")).lower(): found.append({"bucket":m,"marketer":marketer,**c})
    return {"rows":found}
@app.post("/api/marketers/renew-link")
async def api_m_renew(payload: Dict[str, Any]):
    uid=str(payload.get("user_id")); d=crm(); name=d.get("whitelist",{}).get(uid); link=""; public_id=channel_id_value("public_channel_id")
    if name and runtime.marketing_app and public_id:
        obj=await runtime.marketing_app.bot.create_chat_invite_link(chat_id=public_id, name=name); link=obj.invite_link; d.setdefault("active_links",{})[name]=link; save_crm(d)
    return {"ok":bool(link),"link":link}
@app.post("/api/marketers/delete")
async def api_m_delete(payload: Dict[str, Any]):
    d=crm(); uid=str(payload.get("user_id")); name=d.get("whitelist",{}).pop(uid,None); d.get("marketers_data",{}).pop(uid,None); save_crm(d); return {"ok":True,"name":name}
@app.post("/api/marketers/burn-link")
async def api_m_burn(payload: Dict[str, Any]):
    d=crm(); key=str(payload.get("user_id")); name=d.get("whitelist",{}).get(key,key); d.get("active_links",{}).pop(name,None); save_crm(d); return {"ok":True}
@app.post("/api/marketers/burn-all-links")
async def api_m_burn_all():
    d=crm(); d["active_links"]={}; save_crm(d); return {"ok":True}
@app.post("/api/marketers/request-withdrawal")
async def api_m_withdraw(payload: Dict[str, Any]):
    d=crm(); uid=str(payload.get("user_id")); name=d.get("whitelist",{}).get(uid); d.setdefault("withdrawal_requests",{})[uid]={"name":name,"date":now_str(),"clients":d.get("referrals",{}).get(name,[])}; save_crm(d); return {"ok":True}
@app.post("/api/marketers/pay-commission")
async def api_m_pay(payload: Dict[str, Any]):
    cid=int(payload.get("client_id")); d=crm(); found=False
    for m, clients in d.get("referrals",{}).items():
        for i,c in enumerate(list(clients)):
            if c.get("id")==cid:
                del clients[i]; d["paid_count"]=d.get("paid_count",0)+1; found=True; break
        if found: break
    save_crm(d); return {"ok":found}
@app.post("/api/marketers/reject-withdrawal")
async def api_m_reject_withdrawal(payload: Dict[str, Any]): return {"ok":True}
@app.post("/api/marketers/contract/update")
async def api_m_contract(payload: Dict[str, Any]):
    c=cfg(); c.setdefault("marketing_messages",{})["contract_msg"]=payload.get("message",""); save_cfg(c); return {"ok":True}

if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("SERVER_PORT") or os.getenv("PORT") or "8000")
    uvicorn.run("main:app", host="0.0.0.0", port=port, reload=False)
