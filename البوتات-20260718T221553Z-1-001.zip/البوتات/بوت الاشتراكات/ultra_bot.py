import asyncio
import json
from datetime import datetime, timedelta
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, CallbackQueryHandler, MessageHandler, filters
import os
import sys

# --- دوال تحميل وحفظ الإعدادات ---
def load_config_from_file():
    try:
        with open("config.json", "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        print("خطأ: ملف config.json غير موجود.")
        sys.exit(1)

def save_config_to_file(new_config):
    with open("config.json", "w", encoding="utf-8") as f:
        json.dump(new_config, f, ensure_ascii=False, indent=4)

config = load_config_from_file()

BOT_TOKEN = config["bot_token"]
ADMIN_ID = str(config["admin_id"])
DATA_FILE = "subs_data.json"

pending_subs = {}
active_subs = {}
user_flow_data = {}
stats = {"total_revenue": 0.0, "total_subscribers": 0}

# --- خريطة الرسائل ---
EDITABLE_MESSAGES = {
    "📢 ترحيب القناة": "subscription_channel_message",
    "💡 نصائح القناة": "tips_channel",
    "⛔ انتظار القناة": "busy_channel",
    "❌ رفض القناة": "reject_user_channel",
    "⚠️ تنبيه القناة (قبل يوم)": "subscription_expiring_channel",
    "❌ انتهاء القناة": "subscription_ended_channel",

    "📉 ترحيب المؤشر": "subscription_indicator_message",
    "💡 نصائح المؤشر": "tips_indicator",
    "⛔ انتظار المؤشر": "busy_indicator",
    "❌ رفض المؤشر": "reject_user_indicator",
    "⚠️ تنبيه المؤشر (قبل يوم)": "subscription_expiring_indicator",
    "❌ انتهاء المؤشر": "subscription_ended_indicator",
    "📝 طلب يوزر TradingView": "ask_tv_username",
    
    "↩️ رجوع": "back"
}

MSG_CATEGORIES = {
    "channel": ["subscription_channel_message", "tips_channel", "busy_channel", "reject_user_channel", "subscription_expiring_channel", "subscription_ended_channel"],
    "indicator": ["subscription_indicator_message", "tips_indicator", "busy_indicator", "reject_user_indicator", "subscription_expiring_indicator", "subscription_ended_indicator", "ask_tv_username"]
}

# --- دوال مساعدة ---
def get_msg(key):
    try:
        with open("config.json", "r", encoding="utf-8") as f:
            data = json.load(f)
            return "\n".join(data["messages"][key])
    except: return "Error loading message."

def get_config_value(key):
    try:
        with open("config.json", "r", encoding="utf-8") as f:
            data = json.load(f)
            return data.get(key)
    except: return None

def save_msg(key, text_list):
    try:
        with open("config.json", "r", encoding="utf-8") as f: data = json.load(f)
        data["messages"][key] = text_list
        with open("config.json", "w", encoding="utf-8") as f: json.dump(data, f, ensure_ascii=False, indent=4)
    except: pass

def save_setting(key, val):
    try:
        with open("config.json", "r", encoding="utf-8") as f: data = json.load(f)
        data[key] = val
        with open("config.json", "w", encoding="utf-8") as f: json.dump(data, f, ensure_ascii=False, indent=4)
    except: pass

def save_data():
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump({"pending_subs": pending_subs, "active_subs": active_subs, "stats": stats}, f, ensure_ascii=False, indent=4)

if os.path.exists(DATA_FILE):
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
            pending_subs = data.get("pending_subs", {})
            active_subs = data.get("active_subs", {})
            stats = data.get("stats", {"total_revenue": 0.0, "total_subscribers": len(active_subs)})
    except: pending_subs = {}; active_subs = {}; stats = {"total_revenue": 0.0, "total_subscribers": 0}
else: pending_subs = {}; active_subs = {}; stats = {"total_revenue": 0.0, "total_subscribers": 0}

admin_action = {}
editing_key = {} 

def get_user_keyboard(user_id):
    btns_conf = get_config_value("buttons")
    support_btn = btns_conf.get("contact_support", "🗣 خدمة العملاء")
    
    has_channel = False
    has_indicator = False
    if user_id in active_subs:
        if active_subs[user_id].get("channel_end"): has_channel = True
        if active_subs[user_id].get("indicator_end"): has_indicator = True
    
    buttons = []
    if not has_channel and not has_indicator:
        buttons = btns_conf["user_main"].copy()
    else:
        buttons = ["⏳ مدة الاشتراك المتبقية"]
        if not has_channel: buttons.append(btns_conf["add_channel"])
        if not has_indicator: buttons.append(btns_conf["add_indicator"])

    formatted_keyboard = []
    row = []
    for btn in buttons:
        row.append(btn)
        if len(row) == 2: formatted_keyboard.append(row); row = []
    if row: formatted_keyboard.append(row)
    
    formatted_keyboard.append([support_btn])
    
    return ReplyKeyboardMarkup(formatted_keyboard, resize_keyboard=True)

def get_back_keyboard():
    return ReplyKeyboardMarkup([["↩️ رجوع"]], resize_keyboard=True, one_time_keyboard=True)

async def start(update: Update, context):
    if not update.message: return
    user_id = str(update.message.from_user.id)
    global config; config = load_config_from_file()
    if user_id in user_flow_data: del user_flow_data[user_id]

    if user_id == ADMIN_ID:
        raw_buttons = get_config_value("buttons")["admin_main"].copy()
        if "احصائيات عامة 📊" not in raw_buttons: raw_buttons.append("احصائيات عامة 📊")
        keyboard_buttons = []
        row = []
        for btn in raw_buttons:
            row.append(btn)
            if len(row) == 2: keyboard_buttons.append(row); row = []
        if row: keyboard_buttons.append(row)
        await update.message.reply_text(get_msg("welcome_admin"), reply_markup=ReplyKeyboardMarkup(keyboard_buttons, resize_keyboard=True))
    else:
        await update.message.reply_text(get_msg("user_prompt"), reply_markup=get_user_keyboard(user_id))

async def handle_text(update: Update, context):
    if not update.message: return
    user_id = str(update.message.from_user.id)
    text = update.message.text or update.message.caption or ""
    global config; config = load_config_from_file()
    btns = get_config_value("buttons")
    support_txt = btns.get("contact_support", "🗣 خدمة العملاء")

    # --- زر خدمة العملاء ---
    if text == support_txt:
        s_url = get_config_value("support_url")
        kb = [[InlineKeyboardButton("📩 تواصل مع الدعم", url=s_url)]]
        await update.message.reply_text("تفضل بالتواصل معنا مباشرة:", reply_markup=InlineKeyboardMarkup(kb))
        return

    if user_id != ADMIN_ID:
        
        if text in [btns["add_indicator"], btns["add_channel"], "اشتراك"]:
            if user_id in pending_subs:
                p_service = pending_subs[user_id].get("added_service", "channel")
                msg_key = "busy_channel" if p_service == "channel" else "busy_indicator"
                await update.message.reply_text(get_msg(msg_key), reply_markup=get_user_keyboard(user_id))
                return

        if text == btns["add_indicator"]:
            if user_id not in active_subs:
                await update.message.reply_text(get_msg("msg_must_be_sub"), reply_markup=get_user_keyboard(user_id))
                return
            user_flow_data[user_id] = {"step": "waiting_tv_username", "is_addon": True, "target": "indicator"}
            await update.message.reply_text(get_msg("ask_tv_username"))
            return

        if text == btns["add_channel"]:
            if user_id not in active_subs:
                await update.message.reply_text(get_msg("msg_must_be_sub"), reply_markup=get_user_keyboard(user_id))
                return
            user_flow_data[user_id] = {"step": "waiting_duration", "is_addon": True, "target": "channel"}
            ch_durs = btns.get("channel_durations", [])
            await update.message.reply_text(get_msg("choose_subscription"), reply_markup=ReplyKeyboardMarkup([ch_durs], resize_keyboard=True))
            return

        if text in btns["user_main"]:
            if user_id in active_subs:
                await update.message.reply_text(get_msg("already_subscribed"), reply_markup=get_user_keyboard(user_id))
                return
            if user_id in pending_subs:
                await update.message.reply_text(get_msg("busy_channel"), reply_markup=get_user_keyboard(user_id))
                return
            user_flow_data[user_id] = {"step": "waiting_service_type", "is_addon": False}
            await update.message.reply_text(get_msg("choose_service_type"), reply_markup=ReplyKeyboardMarkup([btns["service_types"]], resize_keyboard=True))
            return

        if user_id in user_flow_data:
            step = user_flow_data[user_id].get("step")
            
            if step == "waiting_service_type":
                if text == "📢 قناة تليجرام":
                    user_flow_data[user_id]["target"] = "channel"
                    user_flow_data[user_id]["step"] = "waiting_duration"
                    ch_durs = btns.get("channel_durations", [])
                    await update.message.reply_text(get_msg("choose_subscription"), reply_markup=ReplyKeyboardMarkup([ch_durs], resize_keyboard=True))
                    return
                elif text == "📉 مؤشر TradingView":
                    user_flow_data[user_id]["target"] = "indicator"
                    user_flow_data[user_id]["step"] = "waiting_tv_username"
                    await update.message.reply_text(get_msg("ask_tv_username"))
                    return

            if step == "waiting_tv_username":
                user_flow_data[user_id]["tv_user"] = text
                user_flow_data[user_id]["step"] = "waiting_duration"
                ind_durs = btns.get("indicator_durations", [])
                await update.message.reply_text(f"✅: {text}\n" + get_msg("choose_subscription"), reply_markup=ReplyKeyboardMarkup([ind_durs], resize_keyboard=True))
                return

            if step == "waiting_duration":
                target_service = user_flow_data[user_id].get("target")
                allowed_list = []
                if target_service == "channel": allowed_list = btns.get("channel_durations", [])
                else: allowed_list = btns.get("indicator_durations", [])
                
                if text not in allowed_list:
                    await update.message.reply_text(get_msg("msg_error_duration"))
                    return
                try: days = int(text.split()[0])
                except: return

                tv_user = user_flow_data[user_id].get("tv_user", None)
                if not tv_user and user_id in active_subs: tv_user = active_subs[user_id].get("tv_user")

                pending_subs[user_id] = {
                    "name": update.message.from_user.full_name,
                    "days": days,
                    "added_service": target_service,
                    "tv_user": tv_user
                }
                save_data()
                del user_flow_data[user_id]

                serv_ar = "قناة تليجرام" if target_service == "channel" else "مؤشر TradingView"
                extra = f"📉 TV: {tv_user}" if tv_user else ""
                
                kb_admin = InlineKeyboardMarkup([
                    [InlineKeyboardButton("✅ قبول", callback_data=f"approve_{user_id}"),
                     InlineKeyboardButton("❌ رفض", callback_data=f"reject_{user_id}")]
                ])
                admin_txt = get_msg("subscription_request_admin").format(
                    name=update.message.from_user.full_name, service=serv_ar, extra_info=extra, days=days
                )
                await context.bot.send_message(chat_id=int(ADMIN_ID), text=admin_txt, reply_markup=kb_admin)
                await update.message.reply_text(get_msg("subscription_sent"))
                await update.message.reply_text(get_msg("msg_request_received"), reply_markup=get_user_keyboard(user_id))
                return

        if text == "⏳ مدة الاشتراك المتبقية":
            if user_id in active_subs:
                now = datetime.now()
                msg_parts = []
                if "channel_end" in active_subs[user_id]:
                    try:
                        end_ch = datetime.strptime(active_subs[user_id]["channel_end"], "%Y-%m-%d %H:%M:%S")
                        if end_ch > now:
                            rem = (end_ch - now).days
                            d_str = rem if rem > 0 else "أقل من يوم"
                            msg_parts.append(f"📢 **قناة تليجرام:** متبقي {d_str} يوم")
                    except: pass
                if "indicator_end" in active_subs[user_id]:
                    try:
                        end_ind = datetime.strptime(active_subs[user_id]["indicator_end"], "%Y-%m-%d %H:%M:%S")
                        if end_ind > now:
                            rem = (end_ind - now).days
                            d_str = rem if rem > 0 else "أقل من يوم"
                            msg_parts.append(f"📉 **مؤشر TradingView:** متبقي {d_str} يوم")
                    except: pass
                
                if msg_parts:
                    final_msg = "💎 **تفاصيل اشتراكاتك:**\n\n" + "\n".join(msg_parts)
                    await update.message.reply_text(final_msg, reply_markup=get_user_keyboard(user_id), parse_mode='Markdown')
                else:
                    await update.message.reply_text("❌ لا يوجد اشتراكات نشطة.", reply_markup=get_user_keyboard(user_id))
            else:
                await update.message.reply_text(get_msg("msg_no_subs"), reply_markup=get_user_keyboard(user_id))
            return

    # --- أدوات المشرف ---
    if user_id == ADMIN_ID:
        # إدخال مبلغ الاشتراك
        if user_id in admin_action and isinstance(admin_action[user_id], dict) and admin_action[user_id].get("act") == "waiting_sub_amount":
            if text == "↩️ رجوع":
                admin_action.pop(user_id)
                raw_buttons = get_config_value("buttons")["admin_main"].copy()
                if "احصائيات عامة 📊" not in raw_buttons: raw_buttons.append("احصائيات عامة 📊")
                kb_list = []
                row = []
                for b in raw_buttons:
                    row.append(b)
                    if len(row)==2: kb_list.append(row); row=[]
                if row: kb_list.append(row)
                await update.message.reply_text("تم إلغاء عملية القبول.", reply_markup=ReplyKeyboardMarkup(kb_list, resize_keyboard=True))
                return
            try:
                amount = float(text)
                uid_to_approve = admin_action[user_id]["uid"]
                admin_action.pop(user_id)
                await finalize_approval(context, user_id, uid_to_approve, amount)
            except ValueError:
                await update.message.reply_text("⚠️ يرجى إرسال أرقام فقط (مثال: 50 أو 10.5). حاول مرة أخرى.")
            return

        # زر الإحصائيات - تم تحديثه ليظهر النشطين حالياً
        if text == "احصائيات عامة 📊":
            total_rev = stats.get("total_revenue", 0.0)
            total_subs = stats.get("total_subscribers", 0)
            active_count = len(active_subs) # جلب عدد النشطين من القاموس
            
            txt = (
                "📊 *الإحصائيات العامة للبوت:*\n\n"
                f"👥 إجمالي المشتركين (طوال الوقت): `{total_subs}` مشترك\n"
                f"🟢 المشتركين النشطين حالياً: `{active_count}` مشترك\n"
                f"💰 إجمالي المبالغ المستلمة: `{total_rev}`\n"
            )
            await update.message.reply_text(txt, parse_mode="Markdown")
            return

        if text == "⚙️ إعدادات البوت":
            kb = ReplyKeyboardMarkup([
                ["تغيير رابط القناة", "تغيير رابط المؤشر"],
                ["تغيير رابط الدعم", "تعديل مدد الاشتراك"],
                ["↩️ رجوع"]
            ], resize_keyboard=True)
            await update.message.reply_text("⚙️ الإعدادات:", reply_markup=kb)
            admin_action[user_id] = "settings_menu"
            return

        if text == "↩️ رجوع":
            raw_buttons = get_config_value("buttons")["admin_main"].copy()
            if "احصائيات عامة 📊" not in raw_buttons: raw_buttons.append("احصائيات عامة 📊")
            kb_list = []
            row = []
            for b in raw_buttons:
                row.append(b)
                if len(row)==2: kb_list.append(row); row=[]
            if row: kb_list.append(row)
            await update.message.reply_text(get_msg("msg_admin_main"), reply_markup=ReplyKeyboardMarkup(kb_list, resize_keyboard=True))
            if user_id in admin_action: admin_action.pop(user_id)
            return

        if user_id in admin_action and admin_action[user_id] == "settings_menu":
            if text == "تغيير رابط القناة":
                admin_action[user_id] = "waiting_invite_link"
                await update.message.reply_text("📎 الرابط الجديد:", reply_markup=get_back_keyboard())
                return
            elif text == "تغيير رابط المؤشر":
                admin_action[user_id] = "waiting_indicator_link"
                await update.message.reply_text("📉 الرابط الجديد:", reply_markup=get_back_keyboard())
                return
            elif text == "تغيير رابط الدعم":
                admin_action[user_id] = "waiting_support_link"
                await update.message.reply_text("🗣 يوزر الدعم الجديد:", reply_markup=get_back_keyboard())
                return
            elif text == "تعديل مدد الاشتراك":
                kb = ReplyKeyboardMarkup([["📢 مدد القناة", "📉 مدد المؤشر"], ["↩️ رجوع"]], resize_keyboard=True)
                await update.message.reply_text("اختر الخدمة لتعديل مدتها:", reply_markup=kb)
                admin_action[user_id] = "duration_service_select"
                return

        # 1. اختيار الخدمة
        if user_id in admin_action and admin_action[user_id] == "duration_service_select":
            if text == "↩️ رجوع":
                kb = ReplyKeyboardMarkup([["تغيير رابط القناة", "تغيير رابط المؤشر"], ["تغيير رابط الدعم", "تعديل مدد الاشتراك"], ["↩️ رجوع"]], resize_keyboard=True)
                await update.message.reply_text("الإعدادات:", reply_markup=kb)
                admin_action[user_id] = "settings_menu"
                return
            
            target_key = "channel_durations" if "القناة" in text else "indicator_durations"
            admin_action[user_id] = {"state": "duration_action_select", "target_list": target_key}
            
            kb = ReplyKeyboardMarkup([["➕ إضافة مدة", "➖ حذف مدة", "✏️ تعديل مدة"], ["↩️ رجوع"]], resize_keyboard=True)
            durs = get_config_value("buttons")[target_key]
            dur_txt = "\n".join([f"- {d}" for d in durs])
            await update.message.reply_text(f"⏱ المدد الحالية ({text}):\n{dur_txt}\n\n👇 ماذا تريد أن تفعل؟", reply_markup=kb)
            return

        # 2. اختيار العملية
        if user_id in admin_action and isinstance(admin_action[user_id], dict) and admin_action[user_id].get("state") == "duration_action_select":
            target_list_key = admin_action[user_id]["target_list"]
            
            if text == "➕ إضافة مدة":
                admin_action[user_id]["state"] = "waiting_add_duration"
                await update.message.reply_text("✍️ أرسل المدة الجديدة (مثال: 60 يوم):", reply_markup=get_back_keyboard())
                return
            elif text == "➖ حذف مدة":
                durs = get_config_value("buttons")[target_list_key]
                kb_rows = []
                row = []
                for d in durs:
                    row.append(d)
                    if len(row) == 3: kb_rows.append(row); row = []
                if row: kb_rows.append(row)
                kb_rows.append(["↩️ رجوع"])
                await update.message.reply_text("🗑️ اضغط على المدة لحذفها:", reply_markup=ReplyKeyboardMarkup(kb_rows, resize_keyboard=True))
                admin_action[user_id]["state"] = "choosing_del_duration"
                return
            elif text == "✏️ تعديل مدة":
                durs = get_config_value("buttons")[target_list_key]
                kb_rows = []
                row = []
                for d in durs:
                    row.append(d)
                    if len(row) == 3: kb_rows.append(row); row = []
                if row: kb_rows.append(row)
                kb_rows.append(["↩️ رجوع"])
                await update.message.reply_text("✏️ اضغط على المدة لتعديلها:", reply_markup=ReplyKeyboardMarkup(kb_rows, resize_keyboard=True))
                admin_action[user_id]["state"] = "choosing_edit_duration_target"
                return
            elif text == "↩️ رجوع":
                kb = ReplyKeyboardMarkup([["📢 مدد القناة", "📉 مدد المؤشر"], ["↩️ رجوع"]], resize_keyboard=True)
                await update.message.reply_text("اختر الخدمة:", reply_markup=kb)
                admin_action[user_id] = "duration_service_select"
                return

        # إضافة
        if user_id in admin_action and isinstance(admin_action[user_id], dict) and admin_action[user_id].get("state") == "waiting_add_duration":
            if text != "↩️ رجوع":
                target_key = admin_action[user_id]["target_list"]
                try:
                    with open("config.json", "r", encoding="utf-8") as f: d = json.load(f)
                    if text not in d["buttons"][target_key]:
                        d["buttons"][target_key].append(text)
                        with open("config.json", "w", encoding="utf-8") as f: json.dump(d, f, ensure_ascii=False, indent=4)
                        await update.message.reply_text(get_msg("edit_success"))
                    else:
                        await update.message.reply_text("⚠️ موجودة.")
                except: pass
            
            kb = ReplyKeyboardMarkup([["➕ إضافة مدة", "➖ حذف مدة", "✏️ تعديل مدة"], ["↩️ رجوع"]], resize_keyboard=True)
            await update.message.reply_text("العمليات:", reply_markup=kb)
            admin_action[user_id]["state"] = "duration_action_select"
            return

        # حذف
        if user_id in admin_action and isinstance(admin_action[user_id], dict) and admin_action[user_id].get("state") == "choosing_del_duration":
            target_key = admin_action[user_id]["target_list"]
            if text == "↩️ رجوع":
                kb = ReplyKeyboardMarkup([["➕ إضافة مدة", "➖ حذف مدة", "✏️ تعديل مدة"], ["↩️ رجوع"]], resize_keyboard=True)
                await update.message.reply_text("العمليات:", reply_markup=kb)
                admin_action[user_id]["state"] = "duration_action_select"
                return
            
            try:
                with open("config.json", "r", encoding="utf-8") as f: d = json.load(f)
                if text in d["buttons"][target_key]:
                    d["buttons"][target_key].remove(text)
                    with open("config.json", "w", encoding="utf-8") as f: json.dump(d, f, ensure_ascii=False, indent=4)
                    await update.message.reply_text(f"✅ تم حذف {text}")
                    durs = d["buttons"][target_key]
                    kb_rows = []
                    row = []
                    for d in durs:
                        row.append(d)
                        if len(row)==3: kb_rows.append(row); row=[]
                    if row: kb_rows.append(row)
                    kb_rows.append(["↩️ رجوع"])
                    await update.message.reply_text("حذف آخر:", reply_markup=ReplyKeyboardMarkup(kb_rows, resize_keyboard=True))
                else:
                    await update.message.reply_text("⚠️ غير موجودة.")
            except: pass
            return

        # تعديل (اختيار)
        if user_id in admin_action and isinstance(admin_action[user_id], dict) and admin_action[user_id].get("state") == "choosing_edit_duration_target":
            if text == "↩️ رجوع":
                kb = ReplyKeyboardMarkup([["➕ إضافة مدة", "➖ حذف مدة", "✏️ تعديل مدة"], ["↩️ رجوع"]], resize_keyboard=True)
                await update.message.reply_text("العمليات:", reply_markup=kb)
                admin_action[user_id]["state"] = "duration_action_select"
                return
            
            editing_key[user_id] = text 
            admin_action[user_id]["state"] = "waiting_edit_duration_value"
            await update.message.reply_text(f"📝 النص الحالي: {text}\n👇 الجديد:", reply_markup=get_back_keyboard())
            return

        # تعديل (حفظ)
        if user_id in admin_action and isinstance(admin_action[user_id], dict) and admin_action[user_id].get("state") == "waiting_edit_duration_value":
            old_val = editing_key.get(user_id)
            target_key = admin_action[user_id]["target_list"]
            if text != "↩️ رجوع" and old_val:
                try:
                    with open("config.json", "r", encoding="utf-8") as f: d = json.load(f)
                    if old_val in d["buttons"][target_key]:
                        idx = d["buttons"][target_key].index(old_val)
                        d["buttons"][target_key][idx] = text
                        with open("config.json", "w", encoding="utf-8") as f: json.dump(d, f, ensure_ascii=False, indent=4)
                        await update.message.reply_text(f"✅ تم.")
                    else:
                        await update.message.reply_text("⚠️ خطأ.")
                except: pass
            kb = ReplyKeyboardMarkup([["➕ إضافة مدة", "➖ حذف مدة", "✏️ تعديل مدة"], ["↩️ رجوع"]], resize_keyboard=True)
            await update.message.reply_text("العمليات:", reply_markup=kb)
            admin_action[user_id]["state"] = "duration_action_select"
            return

        # حفظ الروابط
        if user_id in admin_action and admin_action[user_id] == "waiting_invite_link":
            save_setting("channel_link", text)
            await update.message.reply_text(get_msg("edit_success"), reply_markup=get_back_keyboard())
            return

        if user_id in admin_action and admin_action[user_id] == "waiting_indicator_link":
            save_setting("indicator_link", text)
            await update.message.reply_text(get_msg("edit_success"), reply_markup=get_back_keyboard())
            return

        if user_id in admin_action and admin_action[user_id] == "waiting_support_link":
            save_setting("support_url", text)
            await update.message.reply_text(get_msg("edit_success"), reply_markup=get_back_keyboard())
            return

        # تعديل النصوص
        if text == "✏️ تعديل النصوص":
            kb = ReplyKeyboardMarkup([["📢 رسائل القناة", "📉 رسائل المؤشر"], ["↩️ رجوع"]], resize_keyboard=True)
            await update.message.reply_text("📝 اختر القسم:", reply_markup=kb)
            admin_action[user_id] = "choosing_edit_category"
            return

        if user_id in admin_action and admin_action[user_id] == "choosing_edit_category":
            category = None
            if text == "📢 رسائل القناة": category = "channel"
            elif text == "📉 رسائل المؤشر": category = "indicator"
            elif text == "↩️ رجوع":
                admin_action.pop(user_id)
                raw_buttons = get_config_value("buttons")["admin_main"].copy()
                if "احصائيات عامة 📊" not in raw_buttons: raw_buttons.append("احصائيات عامة 📊")
                keyboard_buttons = []
                row = []
                for b in raw_buttons:
                    row.append(b)
                    if len(row)==2: keyboard_buttons.append(row); row=[]
                if row: keyboard_buttons.append(row)
                await update.message.reply_text(get_msg("msg_admin_main"), reply_markup=ReplyKeyboardMarkup(keyboard_buttons, resize_keyboard=True))
                return
            else:
                await update.message.reply_text("❌ خيار غير صحيح.", reply_markup=get_back_keyboard())
                return

            filtered_keys = []
            for btn_text, conf_key in EDITABLE_MESSAGES.items():
                if conf_key in MSG_CATEGORIES[category]:
                    filtered_keys.append(btn_text)

            keyboard_btns = [filtered_keys[i:i + 2] for i in range(0, len(filtered_keys), 2)]
            keyboard_btns.append(["↩️ رجوع"])
            await update.message.reply_text("📝 اختر الرسالة:", reply_markup=ReplyKeyboardMarkup(keyboard_btns, resize_keyboard=True))
            admin_action[user_id] = "choosing_msg"
            return

        if user_id in admin_action and admin_action[user_id] == "choosing_msg":
            if text == "↩️ رجوع":
                kb = ReplyKeyboardMarkup([["📢 رسائل القناة", "📉 رسائل المؤشر"], ["↩️ رجوع"]], resize_keyboard=True)
                await update.message.reply_text("الاقسام:", reply_markup=kb)
                admin_action[user_id] = "choosing_edit_category"
                return
            
            if text in EDITABLE_MESSAGES:
                key = EDITABLE_MESSAGES[text]
                editing_key[user_id] = key
                curr = get_msg(key)
                admin_action[user_id] = "waiting_msg_text"
                await update.message.reply_text(f"📜 الحالي:\n`{curr}`\n\n👇 الجديد:", parse_mode="Markdown", reply_markup=get_back_keyboard())
            return

        if user_id in admin_action and admin_action[user_id] == "waiting_msg_text":
            k = editing_key.get(user_id)
            if k:
                save_msg(k, text.split("\n"))
                await update.message.reply_text(get_msg("edit_success"))
                kb = ReplyKeyboardMarkup([["📢 رسائل القناة", "📉 رسائل المؤشر"], ["↩️ رجوع"]], resize_keyboard=True)
                await update.message.reply_text("اختر قسماً آخر:", reply_markup=kb)
                admin_action[user_id] = "choosing_edit_category"
            return

        # رسالة للكل (مع دعم الصور والفيديو)
        if text == "📢 رسالة للكل":
            kb = InlineKeyboardMarkup([
                [InlineKeyboardButton("📡 للقناة", callback_data="bc_channel")],
                [InlineKeyboardButton("📉 للمؤشر", callback_data="bc_indicator")],
                [InlineKeyboardButton("📣 للكل", callback_data="bc_all")]
            ])
            await update.message.reply_text("اختر:", reply_markup=get_back_keyboard())
            await context.bot.send_message(chat_id=int(user_id), text="القائمة:", reply_markup=kb)
            return

        if user_id in admin_action and isinstance(admin_action[user_id], dict) and admin_action[user_id].get("act") == "bc_text":
            tg = admin_action[user_id]["target"]
            await update.message.reply_text("⏳ جاري الإرسال (نسخ الرسالة)...")
            c = 0
            for uid, info in active_subs.items():
                should = False
                if tg == "all": should = True
                elif tg == "channel" and "channel_end" in info: should = True
                elif tg == "indicator" and "indicator_end" in info: should = True
                if should:
                    try:
                        # استخدام copy_message لدعم كل أنواع الوسائط
                        await context.bot.copy_message(chat_id=int(uid), from_chat_id=user_id, message_id=update.message.message_id)
                        c+=1
                    except: pass
            await update.message.reply_text(f"✅ تم الإرسال لـ {c}")
            admin_action.pop(user_id)
            return

        # حذف
        if text == "❌ حذف مشترك":
            admin_action[user_id] = "del_id"
            await update.message.reply_text("🗑️ الآيدي:", reply_markup=get_back_keyboard())
            return
        
        if user_id in admin_action and admin_action[user_id] == "del_id":
            tid = text.strip()
            if tid in active_subs:
                kb = InlineKeyboardMarkup([
                    [InlineKeyboardButton("🗑️ حذف القناة", callback_data=f"del_ch_{tid}")],
                    [InlineKeyboardButton("🗑️ حذف المؤشر", callback_data=f"del_ind_{tid}")],
                    [InlineKeyboardButton("❌ حذف الكل", callback_data=f"del_all_{tid}")]
                ])
                await update.message.reply_text(f"👤 {active_subs[tid]['name']}", reply_markup=kb)
                admin_action.pop(user_id)
            else: await update.message.reply_text(get_msg("msg_id_not_found"), reply_markup=get_back_keyboard())
            return

        # القائمة
        if text == "📋 قائمة المشتركين":
            msg_c, msg_i = "📡 **قناة:**\n", "\n📉 **مؤشر:**\n"
            found = False
            for uid, info in active_subs.items():
                now = datetime.now()
                if "channel_end" in info:
                    try:
                        rem = (datetime.strptime(info["channel_end"], "%Y-%m-%d %H:%M:%S") - now).days
                        rem = rem if rem >= 0 else 0
                        msg_c += f"👤 {info['name']} | 🆔 `{uid}` | 📅 {rem} يوم\n"
                        found = True
                    except: pass
                if "indicator_end" in info:
                    try:
                        rem = (datetime.strptime(info["indicator_end"], "%Y-%m-%d %H:%M:%S") - now).days
                        rem = rem if rem >= 0 else 0
                        msg_i += f"👤 {info['name']} | 🆔 `{uid}` | 📅 {rem} يوم | TV: `{info.get('tv_user','N/A')}`\n"
                        found = True
                    except: pass
            
            if not found: await update.message.reply_text(get_msg("msg_no_subs"))
            else: await update.message.reply_text(msg_c + "\n━━━━━━━━\n" + msg_i, parse_mode='Markdown')
            return

# دالة إتمام القبول المفصولة (تحتوي على نظام الإحصائيات)
async def finalize_approval(context, admin_id, uid, amount):
    global config; config = load_config_from_file()
    if uid not in pending_subs:
        try: await context.bot.send_message(chat_id=int(admin_id), text=get_msg("msg_already_processed"))
        except: pass
        return
        
    req = pending_subs.pop(uid)
    days = req["days"]
    service = req["added_service"]
    tvu = req.get("tv_user", "N/A")
    name = req["name"]
    
    if uid not in active_subs:
        active_subs[uid] = {"name": name, "tv_user": tvu, "notified_1day": {}}
    
    now = datetime.now()
    new_end = (now + timedelta(days=days)).strftime("%Y-%m-%d %H:%M:%S")
    
    if service == "channel":
        active_subs[uid]["channel_end"] = new_end
        try:
            fmt = {"name": name, "days": days}
            msg = get_msg("subscription_channel_message").format(**fmt)
            kb = [[InlineKeyboardButton("اضغط هنا للانضمام للقناه", url=get_config_value("channel_link"))]]
            await context.bot.send_message(chat_id=int(uid), text=msg, reply_markup=InlineKeyboardMarkup(kb))
            await context.bot.send_message(chat_id=int(uid), text=get_msg("tips_channel"))
        except: pass
        
    elif service == "indicator":
        active_subs[uid]["indicator_end"] = new_end
        if tvu: active_subs[uid]["tv_user"] = tvu
        try:
            fmt = {"name": name, "days": days}
            msg = get_msg("subscription_indicator_message").format(**fmt)
            kb = []
            lnk = get_config_value("indicator_link")
            if lnk: kb.append([InlineKeyboardButton("اضغط هنا لعرض المؤشر", url=lnk)])
            await context.bot.send_message(chat_id=int(uid), text=msg, reply_markup=InlineKeyboardMarkup(kb))
            await context.bot.send_message(chat_id=int(uid), text=get_msg("tips_indicator"))
        except: pass

    # --- إضافة الإحصائيات ---
    stats["total_revenue"] += float(amount)
    stats["total_subscribers"] += 1
    # ------------------------
    
    save_data()
    try: await context.bot.send_message(chat_id=int(uid), text="✅", reply_markup=get_user_keyboard(uid))
    except: pass
    try:
        adm_msg = get_msg("subscription_approved_admin").format(name=name, service=service)
        adm_msg += f"\n\n💰 المبلغ المضاف: {amount}\n📊 الإجمالي الحالي: {stats['total_revenue']}"
        await context.bot.send_message(chat_id=int(admin_id), text=adm_msg)
    except: pass

async def handle_approval(update: Update, context):
    query = update.callback_query
    if not query: return
    await query.answer()
    data = query.data
    uid_admin = str(query.from_user.id)
    global config; config = load_config_from_file()

    if data.startswith("bc_"):
        target = data.replace("bc_", "")
        admin_action[uid_admin] = {"act": "bc_text", "target": target}
        await query.edit_message_text(f"📢 إرسال لـ {target}.. أرسل أي شيء (نص، صورة، فيديو):", parse_mode="Markdown")
        return

    if data.startswith("del_"):
        parts = data.split("_")
        mode = parts[1]
        tid = parts[2]
        if tid not in active_subs: await query.edit_message_text("❌ غير موجود"); return
        
        updated = False
        if mode == "ch" or mode == "all":
            if "channel_end" in active_subs[tid]:
                del active_subs[tid]["channel_end"]
                updated = True
        if mode == "ind" or mode == "all":
            if "indicator_end" in active_subs[tid]:
                del active_subs[tid]["indicator_end"]
                updated = True
        
        if "channel_end" not in active_subs[tid] and "indicator_end" not in active_subs[tid]:
            del active_subs[tid]
        
        if updated:
            save_data()
            await query.edit_message_text("✅ تم الحذف.")
            try: await context.bot.send_message(chat_id=int(tid), text="❌ تم إلغاء الصلاحية.")
            except: pass
        return

    if data.startswith("approve_"):
        uid = data.split("_")[1]
        if uid not in pending_subs: await query.edit_message_text(get_msg("msg_already_processed")); return
        
        admin_action[uid_admin] = {"act": "waiting_sub_amount", "uid": uid}
        
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("مجاناً 🎁", callback_data=f"free_sub_{uid}")]
        ])
        await query.edit_message_text(
            "✅ ممتاز، جاري قبول المشترك.\n\n💰 كم المبلغ الذي استلمته؟\n(أرسل الرقم كرسالة، أو اضغط على زر مجاناً)",
            reply_markup=kb
        )
        return

    if data.startswith("free_sub_"):
        uid = data.split("_")[2]
        if uid_admin in admin_action: admin_action.pop(uid_admin, None)
        await query.edit_message_text("✅ جاري التفعيل (مجاناً)...")
        await finalize_approval(context, uid_admin, uid, 0)
        return

    if data.startswith("reject_"):
        uid = data.split("_")[1]
        msg = get_msg("msg_rejected_user")
        if uid in pending_subs:
            req = pending_subs.pop(uid)
            save_data()
            if req["added_service"] == "channel": msg = get_msg("reject_user_channel")
            else: msg = get_msg("reject_user_indicator")
        
        try: await context.bot.send_message(chat_id=int(uid), text=msg)
        except: pass
        try: await context.bot.send_message(chat_id=int(ADMIN_ID), text=f"تم الرفض {uid}")
        except: pass
        return

async def checker(app):
    await asyncio.sleep(5)
    while True:
        now = datetime.now()
        global config; config = load_config_from_file()
        
        for uid, info in list(active_subs.items()):
            if "channel_end" in info:
                try:
                    end = datetime.strptime(info["channel_end"], "%Y-%m-%d %H:%M:%S")
                    rem = (end - now).days
                    secs = (end - now).total_seconds()
                    notified = info.get("notified_1day", {}).get("channel", False)
                    if rem == 1 and secs > 0 and not notified:
                        await app.bot.send_message(chat_id=int(uid), text=get_msg("subscription_expiring_channel"))
                        adm = get_msg("subscription_expiring_1day_admin").format(name=info["name"], type="قناة")
                        await app.bot.send_message(chat_id=int(ADMIN_ID), text=adm)
                        if "notified_1day" not in active_subs[uid]: active_subs[uid]["notified_1day"] = {}
                        active_subs[uid]["notified_1day"]["channel"] = True
                        save_data()
                    if secs <= 0:
                        await app.bot.send_message(chat_id=int(uid), text=get_msg("subscription_ended_channel"))
                        adm = get_msg("subscription_removed_admin").format(name=info["name"])
                        await app.bot.send_message(chat_id=int(ADMIN_ID), text=adm)
                        del active_subs[uid]["channel_end"]
                        save_data()
                except: pass

            if "indicator_end" in info:
                try:
                    end = datetime.strptime(info["indicator_end"], "%Y-%m-%d %H:%M:%S")
                    rem = (end - now).days
                    secs = (end - now).total_seconds()
                    notified = info.get("notified_1day", {}).get("indicator", False)
                    if rem == 1 and secs > 0 and not notified:
                        await app.bot.send_message(chat_id=int(uid), text=get_msg("subscription_expiring_indicator"))
                        adm = get_msg("subscription_expiring_1day_admin").format(name=info["name"], type="مؤشر")
                        await app.bot.send_message(chat_id=int(ADMIN_ID), text=adm)
                        if "notified_1day" not in active_subs[uid]: active_subs[uid]["notified_1day"] = {}
                        active_subs[uid]["notified_1day"]["indicator"] = True
                        save_data()
                    if secs <= 0:
                        await app.bot.send_message(chat_id=int(uid), text=get_msg("subscription_ended_indicator"))
                        adm = get_msg("subscription_removed_admin").format(name=info["name"])
                        await app.bot.send_message(chat_id=int(ADMIN_ID), text=adm)
                        del active_subs[uid]["indicator_end"]
                        save_data()
                except: pass
            
            if "channel_end" not in active_subs[uid] and "indicator_end" not in active_subs[uid]:
                del active_subs[uid]
                save_data()
        await asyncio.sleep(60)

if __name__ == "__main__":
    app = ApplicationBuilder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler((filters.ALL) & ~filters.COMMAND, handle_text))
    app.add_handler(CallbackQueryHandler(handle_approval))

    async def on_startup(app):
        app.create_task(checker(app))
    
    app.post_init = on_startup
    app.run_polling(poll_interval=1.0)