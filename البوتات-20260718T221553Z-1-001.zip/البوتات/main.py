import subprocess
import sys
import os

def main():
    print("🚀 جاري تشغيل البوتات من المجلدات المخصصة...")
    
    # 1. تشغيل بوت التسويق من داخل مجلده
    # استخدام cwd يضمن أن البوت سيقرأ ملفات json الخاصة به من داخل المجلد
    bot1 = subprocess.Popen([sys.executable, "prof_bot.py"], cwd="بوت التسويق")
    
    # 2. تشغيل بوت الاشتراكات من داخل مجلده
    # استبدل ultra_bot.py باسم ملف البوت الثاني لديك إذا كان مختلفاً
    bot2 = subprocess.Popen([sys.executable, "ultra_bot.py"], cwd="بوت الاشتراكات")
    
    # إبقاء السيرفر يعمل
    bot1.wait()
    bot2.wait()

if __name__ == '__main__':
    main()
