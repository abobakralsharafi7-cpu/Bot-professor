import logging
import json
import os
from datetime import datetime
from telegram import Update, ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, ChatMemberHandler, ContextTypes, filters
from telegram.constants import ChatMemberStatus

# ==========================================
# ⚙️ إعدادات البروفيسور
# ==========================================
TOKEN = "8548430505:AAHInnrlmzAEIz3kRXxnUzqnBWJkcrbsO68"
ADMIN_ID = 7236783321
CHANNEL_ID = -1003301258242
VIP_CHANNEL_ID = -1003209855522
DATA_FILE = "prof_crm.json"

logging.basicConfig(format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO)

# --- 💾 إدارة البيانات الآمنة (تدعم الملفات القديمة وتسد الثغرة) ---
def load_data():
    default_data = {
        "whitelist": {}, "referrals": {}, "active_links": {}, "paid_count": 0, 
        "total_joined": 0, "marketers_data": {}, "public_leads": {}, "pending_requests": {},
        "historical_clients": {}, # 🛡️ الذاكرة الفولاذية لسد ثغرة التكرار وتتبع التجديد
        "settings": {"contract_msg": "📝 أهلاً بك كمسوق معتمد.\nهذه رسالة العقد والشروط الافتراضية، يرجى الالتزام بها لضمان استمرارية الشراكة."}
    }
    if not os.path.exists(DATA_FILE):
        return default_data
    try:
        with open(DATA_FILE, "r", encoding='utf-8') as f:
            data = json.load(f)
            for key, val in default_data.items():
                if key not in data: data[key] = val
            
            if "contract_msg" not in data.get("settings", {}):
                data.setdefault("settings", {})["contract_msg"] = default_data["settings"]["contract_msg"]
                
            for uid, name in list(data.get("whitelist", {}).items()):
                if uid not in data["marketers_data"]:
                    data["marketers_data"][uid] = {
                        "name": name, "commission": "غير محددة",
                        "join_date": "مسجل مسبقاً", "total_brought": len(data.get("referrals", {}).get(name, []))
                    }
            
            if not data.get("historical_clients"):
                data["historical_clients"] = {}
                for m, leads in data.get("public_leads", {}).items():
                    for lead in leads: data["historical_clients"][str(lead["id"])] = m
                for m, refs in data.get("referrals", {}).items():
                    for ref in refs: data["historical_clients"][str(ref["id"])] = m
                save_data(data)

            return data
    except Exception as e:
        logging.error(f"Error loading data: {e}")
        return default_data

def save_data(data):
    with open(DATA_FILE, "w", encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=4)

# --- 🔘 القوائم ---
def get_main_keyboard(user_id):
    if user_id == ADMIN_ID:
        return ReplyKeyboardMarkup([[KeyboardButton("📢 لوحة الإدارة")]], resize_keyboard=True)
    data = load_data()
    if str(user_id) in data["whitelist"]:
        return ReplyKeyboardMarkup([[KeyboardButton("💼 قسم المسوقين")]], resize_keyboard=True)
    return ReplyKeyboardMarkup([[KeyboardButton("🤝 طلب الانضمام كمسوق")]], resize_keyboard=True)

def get_admin_panel():
    return ReplyKeyboardMarkup([
        [KeyboardButton("ℹ️ معلومات مسوق"), KeyboardButton("📝 تحديد/تعديل عمولة")],
        [KeyboardButton("📊 كشف العملاء المعلقين"), KeyboardButton("📈 إحصائيات عامة")],
        [KeyboardButton("🔍 فحص مصدر عميل"), KeyboardButton("⚙️ الإعدادات")],
        [KeyboardButton("🔙 خروج")]
    ], resize_keyboard=True)

def get_settings_panel():
    return ReplyKeyboardMarkup([
        [KeyboardButton("📝 تعديل رسالة العقد")],
        [KeyboardButton("♻️ تجديد رابط مسوق"), KeyboardButton("🗑 حذف مسوق")],
        [KeyboardButton("🔥 حرق رابط محدد"), KeyboardButton("🔥 حرق جميع الروابط")],
        [KeyboardButton("🔙 رجوع للإدارة")]
    ], resize_keyboard=True)

# --- 🧠 استخراج الآيدي ---
def extract_id(update: Update):
    msg = update.message
    if msg.forward_origin and hasattr(msg.forward_origin, 'sender_user'): return msg.forward_origin.sender_user.id
    if msg.text and msg.text.strip().isdigit(): return int(msg.text.strip())
    return None

# --- 🎮 المعالج الرئيسي ---
async def master_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        if not update.message: return
        user_id = update.effective_user.id
        text = update.message.text if update.message.text else ""
        data = load_data()
        mode = context.user_data.get('mode')

        # معالجة طلب الانضمام
        if text == "🤝 طلب الانضمام كمسوق" and str(user_id) not in data["whitelist"] and user_id != ADMIN_ID:
            if str(user_id) in data.get("pending_requests", {}):
                await update.message.reply_text("⏳ لقد قمت بإرسال طلب مسبقاً، يرجى انتظار مراجعة الإدارة.")
            else:
                data.setdefault("pending_requests", {})[str(user_id)] = True
                save_data(data)
                await update.message.reply_text("✅ تم إرسال طلبك للإدارة بنجاح. سيصلك إشعار فور مراجعته.")
                
                user_fullname = update.effective_user.full_name
                username = f"@{update.effective_user.username}" if update.effective_user.username else "لا يوجد"
                msg = f"🔔 طلب انضمام مسوق جديد!\n\nالاسم: {user_fullname}\nالمعرف: {username}\nالآيدي: {user_id}"
                keyboard = [[InlineKeyboardButton("✅ قبول واعتماد", callback_data=f"acceptjoin_{user_id}")],
                            [InlineKeyboardButton("❌ رفض", callback_data=f"rejectjoin_{user_id}")]]
                await context.bot.send_message(chat_id=ADMIN_ID, text=msg, reply_markup=InlineKeyboardMarkup(keyboard))
            return

        if user_id != ADMIN_ID and str(user_id) not in data["whitelist"]: return
        
        if text == "🔙 خروج":
            context.user_data.clear()
            await update.message.reply_text("🏠 القائمة الرئيسية.", reply_markup=get_main_keyboard(user_id))
            return
            
        if text == "🔙 رجوع للإدارة" and user_id == ADMIN_ID:
            context.user_data.clear()
            await update.message.reply_text("⚙️ غرفة القيادة:", reply_markup=get_admin_panel())
            return

        # ==========================================
        # 👑 قسم المدير (البروفيسور)
        # ==========================================
        if user_id == ADMIN_ID:
            if text == "📢 لوحة الإدارة":
                context.user_data.clear()
                await update.message.reply_text("⚙️ أهلاً بك يا بروفيسور في غرفة القيادة.", reply_markup=get_admin_panel())
                return
                
            if text == "⚙️ الإعدادات":
                await update.message.reply_text("🛠️ قسم الإعدادات المتقدمة:", reply_markup=get_settings_panel())
                return
                
            if text == "📝 تعديل رسالة العقد":
                context.user_data['mode'] = 'wait_contract_msg'
                current_msg = data.get("settings", {}).get("contract_msg", "غير متوفرة")
                await update.message.reply_text(f"الرسالة الحالية:\n\n{current_msg}\n\n⌨️ أرسل الآن رسالة العقد الجديدة:", reply_markup=ReplyKeyboardMarkup([["🔙 رجوع للإدارة"]], resize_keyboard=True))
                return
                
            if mode == 'wait_contract_msg':
                if text != "🔙 رجوع للإدارة":
                    data.setdefault("settings", {})["contract_msg"] = text
                    save_data(data)
                    await update.message.reply_text("✅ تم حفظ رسالة العقد الجديدة بنجاح. ستصل لأي مسوق يتم اعتماده من الآن فصاعداً.", reply_markup=get_settings_panel())
                context.user_data.clear()
                return
            
            if text == "📈 إحصائيات عامة":
                t_active_marketers = len(data["whitelist"])
                t_pending_vip = sum(len(c) for c in data["referrals"].values())
                t_pending_public = sum(len(c) for c in data["public_leads"].values())
                t_paid = data.get("paid_count", 0)
                t_historical = len(data.get("historical_clients", {}))
                
                msg = (f"📊 الإحصائيات الشاملة (Professor VIP) 👑\n\n"
                       f"🟢 المسوقين (النشطين حالياً): {t_active_marketers}\n"
                       f"✅ عملاء تم دفع عمولتهم: {t_paid}\n"
                       f"⏳ عملاء معلقين (اشتركوا بالخاصة ولم يتم الدفع): {t_pending_vip}\n"
                       f"👀 عملاء معلقين (في العامة فقط ولم يشتركوا بالخاصة): {t_pending_public}\n"
                       f"🛡️ إجمالي العملاء في الذاكرة الفولاذية (مانع التكرار): {t_historical}")
                await update.message.reply_text(msg)
                return

            if text == "ℹ️ معلومات مسوق":
                if not data["whitelist"]: return await update.message.reply_text("📭 لا يوجد مسوقين حالياً.")
                btns = [[InlineKeyboardButton(f"ℹ️ {n}", callback_data=f"minfo_{u}")] for u, n in data["whitelist"].items()]
                await update.message.reply_text("اختر المسوق لعرض بطاقته الشاملة:", reply_markup=InlineKeyboardMarkup(btns))
                return

            if text == "📝 تحديد/تعديل عمولة":
                if not data["whitelist"]: return await update.message.reply_text("📭 لا يوجد مسوقين حالياً.")
                btns = [[InlineKeyboardButton(f"📝 {n}", callback_data=f"setcomm_{u}")] for u, n in data["whitelist"].items()]
                await update.message.reply_text("اختر المسوق لتحديد أو تعديل عمولته:", reply_markup=InlineKeyboardMarkup(btns))
                return

            if text == "♻️ تجديد رابط مسوق":
                if not data["whitelist"]: return await update.message.reply_text("📭 لا يوجد مسوقين.")
                btns = [[InlineKeyboardButton(f"♻️ {n}", callback_data=f"burn_{u}")] for u, n in data["whitelist"].items()]
                await update.message.reply_text("اختر المسوق لحرق رابطه القديم وإصدار رابط جديد:", reply_markup=InlineKeyboardMarkup(btns))
                return

            if text == "🔥 حرق رابط محدد":
                if not data["active_links"]: return await update.message.reply_text("📭 لا توجد روابط نشطة.")
                btns = [[InlineKeyboardButton(f"🔥 إيقاف رابط: {n}", callback_data=f"kill_{n}")] for n in data["active_links"].keys()]
                await update.message.reply_text("اختر الرابط الذي تريد إيقافه نهائياً:", reply_markup=InlineKeyboardMarkup(btns))
                return

            if text == "🔥 حرق جميع الروابط":
                if not data.get("active_links"): return await update.message.reply_text("📭 لا توجد روابط محفوظة.")
                await update.message.reply_text("⏳ جاري الحرق...")
                count = 0
                for name, link in list(data["active_links"].items()):
                    try:
                        await context.bot.revoke_chat_invite_link(chat_id=CHANNEL_ID, invite_link=link)
                        count += 1
                    except: pass
                data["active_links"] = {}
                save_data(data)
                await update.message.reply_text(f"✅ تم حرق {count} رابط بنجاح.")
                return

            if text == "🔍 فحص مصدر عميل":
                context.user_data['mode'] = 'wait_check'
                await update.message.reply_text("🔎 قم بتحويل رسالة من العميل (Forward)، أو أرسل (اسم، معرف، أو آيدي العميل) لفحصه:", reply_markup=ReplyKeyboardMarkup([["🔙 رجوع للإدارة"]], resize_keyboard=True))
                return

            if mode and mode.startswith('edit_comm_'):
                u = mode.split('_')[2]
                comm = text.strip()
                if u in data["marketers_data"]:
                    data["marketers_data"][u]["commission"] = comm
                    save_data(data)
                    try: await context.bot.send_message(chat_id=int(u), text=f"🔔 إشعار إداري (VIP):\n\nتم اعتماد نسبة عمولتك لتكون: {comm} 💰\nاستمر في التألق يا بطل! 🚀")
                    except: pass
                    await update.message.reply_text(f"✅ تم الحفظ!\nالعمولة الجديدة للمسوق ({data['whitelist'][u]}) هي: {comm}\nوتم إرسال إشعار له.", reply_markup=get_admin_panel())
                context.user_data.clear()
                return

            if mode == 'wait_name':
                name = text.lower().strip()
                context.user_data['temp_name'] = name
                context.user_data['mode'] = 'wait_comm'
                markup = ReplyKeyboardMarkup([["ليس الآن"], ["🔙 رجوع للإدارة"]], resize_keyboard=True, one_time_keyboard=True)
                await update.message.reply_text(f"✅ الاسم: {name}\n\n💰 كم نسبة العمولة التي تريد تحديدها له؟\n(اكتب مثلاً 30% أو 50$، أو اضغط زر 'ليس الآن'):", reply_markup=markup)
                return
                
            if mode == 'wait_comm':
                m_id = context.user_data['temp_id']
                name = context.user_data['temp_name']
                comm = text.strip() if text != "ليس الآن" else "غير محددة"
                
                data["whitelist"][m_id] = name
                if name not in data["referrals"]: data["referrals"][name] = []
                data["marketers_data"][m_id] = {"name": name, "commission": comm, "join_date": datetime.now().strftime("%Y-%m-%d"), "total_brought": 0}
                
                try:
                    link = await context.bot.create_chat_invite_link(chat_id=CHANNEL_ID, name=name)
                    invite_link = link.invite_link
                    data["active_links"][name] = invite_link
                    save_data(data)
                    
                    try:
                        comm_text = f"\n💰 نسبة عمولتك المعتمدة: {comm}\n" if comm != "غير محددة" else ""
                        welcome_msg = (f"أهلاً بك يا شريك النجاح ({name}) في اللوحة التنفيذية! 👑\n\n"
                                       f"نحن سعداء بوجودك ضمن نخبة مسوقي البروفيسور.\n{comm_text}\n"
                                       f"🔗 رابط التسويق الخاص بك (VIP):\n{invite_link}\n\n"
                                       f"🚀 ابدأ بنشر الرابط الآن، فكل عميل هو خطوة نحو أرباح مضاعفة! 💸")
                        
                        keyboard = [[KeyboardButton("💰 رصيدي الحالي"), KeyboardButton("🔗 رابطي التسويقي")],
                                    [KeyboardButton("💸 طلب سحب الأرباح")], [KeyboardButton("🔙 خروج")]]
                        await context.bot.send_message(chat_id=int(m_id), text=welcome_msg, reply_markup=ReplyKeyboardMarkup(keyboard, resize_keyboard=True))
                        
                        contract_msg = data.get("settings", {}).get("contract_msg", "")
                        if contract_msg:
                            await context.bot.send_message(chat_id=int(m_id), text=f"📄 وثيقة العمل والشروط:\n\n{contract_msg}")
                            
                        status = "✅ وتم إشعار المسوق بالرابط، العمولة، ورسالة العقد."
                    except: status = "⚠️ (المسوق لم يراسل البوت بعد أو قام بحظره)."

                    msg = f"🎉 تم اعتماد المسوق بنجاح!\nالاسم: {name}\nالعمولة: {comm}\nالرابط: {invite_link}\n{status}"
                except Exception as e:
                    msg = f"✅ تم الحفظ.\n❌ خطأ بتوليد الرابط (تأكد من رفع البوت كمشرف في القناة العامة): {e}"
                    save_data(data)
                
                await update.message.reply_text(msg, reply_markup=get_admin_panel())
                context.user_data.clear()
                return

            if mode == 'wait_check':
                target_username, target_id, target_name = None, None, None
                
                if update.message.forward_origin and hasattr(update.message.forward_origin, 'sender_user') and update.message.forward_origin.sender_user:
                    sender = update.message.forward_origin.sender_user
                    target_id = sender.id
                    target_username = sender.username.lower() if sender.username else None
                    target_name = sender.full_name.lower()
                    await update.message.reply_text("🔄 جاري الفحص الذكي المتسلسل من الرسالة المحولة...")
                else:
                    if text.startswith('@'): target_username = text.replace('@', '').lower()
                    else:
                        extracted = extract_id(update)
                        if extracted: target_id = extracted
                        else: target_name = text.lower().strip()
                
                if not target_id and not target_username and not target_name:
                    return await update.message.reply_text("⚠️ بيانات غير صالحة. يرجى إرسال آيدي، يوزر، اسم، أو تحويل رسالة من العميل.")

                found = False
                for m_name, clients in data["referrals"].items():
                    for c_info in clients:
                        match = False
                        if target_id and c_info['id'] == target_id: match = True
                        elif target_username and c_info.get('username') and c_info['username'].lower() == target_username: match = True
                        elif target_name and target_name in c_info['n'].lower(): match = True
                            
                        if match:
                            msg = (f"🕵️‍♂️ نتيجة الفحص:\n\n👤 العميل: {c_info['n']}\n🔖 المعرف: @{c_info.get('username', 'لا يوجد')}\n"
                                   f"💼 يتبع المسوق: {m_name}\n📅 الانضمام: {c_info['d']}\n\n❓ هل تريد دفع العمولة للمسوق وتصفية الحساب؟")
                            keyboard = [[InlineKeyboardButton("✅ تم الدفع (تصفية الحساب)", callback_data=f"pay_{c_info['id']}")],
                                        [InlineKeyboardButton("🔙 رجوع", callback_data="cancel_pay")]]
                            await update.message.reply_text(msg, reply_markup=InlineKeyboardMarkup(keyboard))
                            found = True; break
                    if found: break
                
                if not found: await update.message.reply_text("❌ لم يتم العثور على العميل. ربما تم حذفه مسبقاً، أو أنه مخفي البيانات بالكامل.")
                context.user_data.clear()
                await update.message.reply_text("⚙️", reply_markup=get_admin_panel())
                return

            if text == "📊 كشف العملاء المعلقين":
                active_names = list(data["whitelist"].values())
                display_names = [n for n, clients in data["referrals"].items() if n in active_names or len(clients) > 0 or len(data["public_leads"].get(n, [])) > 0]
                
                if not display_names: return await update.message.reply_text("📭 لا توجد بيانات أو عملاء معلقين حالياً.")
                btns = [[InlineKeyboardButton(n, callback_data=f"rep_{n}")] for n in display_names]
                await update.message.reply_text("اختر المسوق لعرض عملائه المعلقين:", reply_markup=InlineKeyboardMarkup(btns))
                return
                
            if text == "🗑 حذف مسوق":
                btns = [[InlineKeyboardButton(f"❌ سحب صلاحية {n}", callback_data=f"del_{u}")] for u, n in data["whitelist"].items()]
                await update.message.reply_text("اختر المسوق لسحب صلاحياته:", reply_markup=InlineKeyboardMarkup(btns))
                return

        # ==========================================
        # 💼 قسم المسوق 
        # ==========================================
        elif str(user_id) in data["whitelist"]:
            if text == "💼 قسم المسوقين":
                keyboard = [[KeyboardButton("💰 رصيدي الحالي"), KeyboardButton("🔗 رابطي التسويقي")],
                            [KeyboardButton("💸 طلب سحب الأرباح")], [KeyboardButton("🔙 خروج")]]
                await update.message.reply_text("💎 لوحة تحكم المسوق:", reply_markup=ReplyKeyboardMarkup(keyboard, resize_keyboard=True))
                
            elif text == "🔗 رابطي التسويقي":
                name = data["whitelist"][str(user_id)]
                link = data["active_links"].get(name)
                if link: await update.message.reply_text(f"🔗 رابط التسويق (VIP) الخاص بك:\n\n{link}\n\n🚀 انسخ الرابط وانشره الآن لمضاعفة أرباحك!")
                else: await update.message.reply_text("⚠️ عذراً، لم يتم العثور على رابط نشط لك. يرجى التواصل مع الإدارة لإصدار رابط جديد.")
                    
            elif text == "💰 رصيدي الحالي":
                name = data["whitelist"][str(user_id)]
                pending_vip = len(data["referrals"].get(name, []))
                pending_public = len(data["public_leads"].get(name, []))
                comm = data["marketers_data"].get(str(user_id), {}).get("commission", "غير محددة")
                total_brought = data["marketers_data"].get(str(user_id), {}).get("total_brought", 0)
                paid_count = total_brought - pending_vip
                
                await update.message.reply_text(f"📊 حصاد أرباحك (معلومات تفصيلية):\n\n💰 نسبتك المعتمدة: {comm}\n\n"
                                                f"✅ عملاء تم دفع عمولتهم: {paid_count}\n⏳ عملاء معلقين (اشتركوا بالخاصة ولم يتم الدفع): {pending_vip}\n"
                                                f"👀 عملاء معلقين (في العامة فقط ولم يشتركوا بالخاصة): {pending_public}\n\n"
                                                f"تواصل مع الإدارة أو استخدم زر طلب السحب لاستلام أرباحك المستحقة! 💰")
                                                
            elif text == "💸 طلب سحب الأرباح":
                name = data["whitelist"][str(user_id)]
                pending_clients = data["referrals"].get(name, [])
                
                if len(pending_clients) == 0: await update.message.reply_text("⚠️ عذراً، لا يوجد لديك عملاء معلقين مستحقين للأرباح حالياً.")
                else:
                    await update.message.reply_text("⏳ جاري إرسال طلبات السحب للإدارة المباشرة...")
                    for client in pending_clients:
                        msg = (f"💸 طلب سحب أرباح! 🔔\n\n💼 المسوق: {name}\n👤 العميل: {client['n']}\n🆔 آيدي العميل: {client['id']}\n"
                               f"📅 تاريخ الانضمام للخاصة: {client['d']}\n\nهل توافق على دفع العمولة وتصفية هذا العميل؟")
                        keyboard = [[InlineKeyboardButton("✅ قبول ودفع", callback_data=f"pay_{client['id']}")],
                                    [InlineKeyboardButton("❌ رفض", callback_data=f"rejectreq_{client['id']}_{user_id}")]]
                        await context.bot.send_message(chat_id=ADMIN_ID, text=msg, reply_markup=InlineKeyboardMarkup(keyboard))
                    await update.message.reply_text("✅ تم إرسال طلب السحب بنجاح. سيصلك إشعار فور مراجعته من الإدارة.")

    except Exception as e:
        await update.message.reply_text(f"🚨 حدث خطأ: {e}")

# --- 📡 الرادار المزدوج ومانع الثغرات (Anti-Fraud & Renewals) ---
async def track_joins(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.chat_member: return
    res = update.chat_member
    
    chat_id = update.effective_chat.id
    print(f"[RADAR DEBUG] Event received in Chat ID: {chat_id} | Type: {res.new_chat_member.status}")
    
    if res.new_chat_member.status == ChatMemberStatus.MEMBER and res.old_chat_member.status != ChatMemberStatus.MEMBER:
        data = load_data()
        user = res.new_chat_member.user
        uid_str = str(user.id)
        info = {"id": user.id, "n": user.full_name, "d": datetime.now().strftime("%Y-%m-%d %H:%M"), "username": user.username if user.username else "لا يوجد"}

        if chat_id == CHANNEL_ID:
            print(f"[RADAR DEBUG] User joined Public Channel: {user.full_name}")
            if res.invite_link and res.invite_link.name:
                m_name = res.invite_link.name.lower()
                
                if uid_str in data.get("historical_clients", {}):
                    old_marketer = data["historical_clients"][uid_str]
                    print(f"[ANTI-FRAUD] User {user.full_name} tried to rejoin via {m_name}. Previously via {old_marketer}.")
                    try:
                        await context.bot.send_message(
                            chat_id=ADMIN_ID,
                            text=f"⚠️ محاولة انضمام مكررة (سد ثغرة) 🚨\n\n"
                                 f"العميل: {info['n']}\n"
                                 f"الآيدي: {info['id']}\n"
                                 f"المسوق الحالي: {m_name}\n\n"
                                 f"❌ هذا العميل مسجل مسبقاً في النظام (جاء سابقاً عبر: {old_marketer}).\n"
                                 f"تم حظره من قائمة العمولات الجديدة ولن يتم احتسابه."
                        )
                    except: pass
                else:
                    if m_name not in data["public_leads"]: data["public_leads"][m_name] = []
                    
                    if not any(c['id'] == info['id'] for c in data["public_leads"][m_name]) and not any(c['id'] == info['id'] for c in data.get("referrals", {}).get(m_name, [])):
                        data["public_leads"][m_name].append(info)
                        data.setdefault("historical_clients", {})[uid_str] = m_name 
                        save_data(data)
                        
                        m_id = next((uid for uid, n in data["whitelist"].items() if n == m_name), None)
                        
                        try: 
                            await context.bot.send_message(chat_id=ADMIN_ID, text=f"🔔 انضمام مبدئي (للعامة) ⏳\n\nالمسوق: {m_name}\nالعميل: {info['n']}\n(تم حفظه في الذاكرة لمنع التكرار مستقبلاً).")
                            if m_id: await context.bot.send_message(chat_id=int(m_id), text=f"👀 إشعار:\nعميل جديد ({info['n']}) انضم للقناة العامة عبر رابطك للتو.\n(العميل في مرحلة المتابعة، ولن يظهر في رصيدك إلا عندما يشترك فعلياً في القناة الخاصة).")
                        except: pass
            else:
                print(f"[RADAR DEBUG] User joined Public Channel but NO invite link was detected.")

        elif chat_id == VIP_CHANNEL_ID:
            print(f"[RADAR DEBUG] User joined VIP Channel: {user.full_name}")
            found_marketer = None
            lead_info = None
            
            for m_name, leads in data["public_leads"].items():
                for i, lead in enumerate(leads):
                    if lead['id'] == user.id:
                        found_marketer = m_name; lead_info = lead
                        del data["public_leads"][m_name][i]
                        break
                if found_marketer: break
            
            if found_marketer and lead_info:
                if found_marketer not in data["referrals"]: data["referrals"][found_marketer] = []
                data["referrals"][found_marketer].append(lead_info)
                data["total_joined"] = data.get("total_joined", 0) + 1 
                
                m_id = next((uid for uid, n in data["whitelist"].items() if n == found_marketer), None)
                if m_id and m_id in data["marketers_data"]:
                    data["marketers_data"][m_id]["total_brought"] = data["marketers_data"][m_id].get("total_brought", 0) + 1
                
                save_data(data)
                try: 
                    await context.bot.send_message(chat_id=ADMIN_ID, text=f"💸 اشتراك فعلي مؤكد! (VIP) ✅\n\nالمسوق: {found_marketer}\nالعميل: {lead_info['n']}\nالمعرف: @{lead_info['username']}\nالآيدي: {lead_info['id']}\nتاريخ الدخول: {lead_info['d']}\n\nتمت إضافته لرصيد المسوق بنجاح.")
                    if m_id: await context.bot.send_message(chat_id=int(m_id), text=f"🎉 مبروك! اشتراك فعلي مؤكد ✅\n\nالعميل ({lead_info['n']}) قام بالاشتراك الفعلي الآن.\nتمت إضافة العميل لرصيدك وأصبح لديك عمولة أرباح مستحقة منه! 💰")
                except: pass
            else:
                # 🛡️ إذا اشترك في الـ VIP بشكل عضوي (بدون مسوق)
                if uid_str not in data.get("historical_clients", {}):
                    data.setdefault("historical_clients", {})[uid_str] = "عضوي (بدون مسوق)"
                    save_data(data)
                    try: await context.bot.send_message(chat_id=ADMIN_ID, text=f"ℹ️ اشتراك جديد (عضوي) في القناة الخاصة\n\nالعميل: {info['n']}\nالمعرف: @{info['username']}\nالآيدي: {info['id']}\n\n(هذا العميل لم يأتِ عبر مسوق، وتم تسجيله كعضوي).")
                    except: pass
                else:
                    # ♻️ العميل مسجل من قبل (سواء عضوي أو عبر مسوق) وعاد للاشتراك
                    old_marketer = data["historical_clients"][uid_str]
                    try: await context.bot.send_message(chat_id=ADMIN_ID, text=f"🔄 تجديد اشتراك (عميل سابق) ♻️\n\nالعميل: {info['n']}\nالمعرف: @{info['username']}\nالآيدي: {info['id']}\n\n(هذا العميل مسجل من قبل في قاعدة البيانات عبر: [{old_marketer}]، وهذا يعتبر تجديد اشتراك وليس عميل جديد).")
                    except: pass
        else:
            print(f"[RADAR WARNING] Ignored Chat ID {chat_id}. Doesn't match Public ({CHANNEL_ID}) or VIP ({VIP_CHANNEL_ID}).")

# --- 🖱️ معالج الأزرار المدمجة ---
async def callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer(); data = load_data()
    
    if q.data.startswith("rejectjoin_"):
        uid = q.data.split("_")[1]
        if uid in data.get("pending_requests", {}): del data["pending_requests"][uid]; save_data(data)
        await q.message.edit_text("❌ تم رفض طلب الانضمام.")
        try: await context.bot.send_message(chat_id=int(uid), text="❌ عذراً، تم رفض طلب انضمامك كمسوق من قبل الإدارة.")
        except: pass
        return

    if q.data.startswith("acceptjoin_"):
        uid = q.data.split("_")[1]
        if uid in data.get("pending_requests", {}): del data["pending_requests"][uid]; save_data(data)
        context.user_data['temp_id'] = uid
        context.user_data['mode'] = 'wait_name'
        await q.message.edit_text(f"✅ تم قبول الطلب مبدئياً للآيدي {uid}.\n⌨️ يرجى كتابة الاسم للمسوق (English):")
        return

    if q.data == "cancel_pay":
        await q.message.edit_text("🔙 تم الإلغاء.")
        return

    if q.data.startswith("rejectreq_"):
        parts = q.data.split("_"); c_id = int(parts[1]); m_id = int(parts[2])
        client_name = "غير معروف"
        for m_name, clients in data["referrals"].items():
            for c in clients:
                if c['id'] == c_id: client_name = c['n']; break
        await q.message.edit_text(f"❌ تم رفض طلب سحب العميل: {client_name}.")
        try: await context.bot.send_message(chat_id=m_id, text=f"❌ عذراً، تم رفض طلب سحب الأرباح للعميل ({client_name}).\nيرجى التواصل مع المشرف للاستفسار.")
        except: pass
        return

    if q.data.startswith("minfo_"):
        u = q.data.split("_")[1]
        if u in data["marketers_data"]:
            m = data["marketers_data"][u]
            link = data["active_links"].get(m["name"], "لا يوجد / محذوف")
            pending_vip = len(data["referrals"].get(m["name"], []))
            pending_public = len(data["public_leads"].get(m["name"], []))
            total_brought = m.get('total_brought', 0)
            paid_count = total_brought - pending_vip

            msg = (f"ℹ️ البطاقة الشاملة للمسوق (VIP) 👑\n\n👤 الاسم: {m['name']}\n🆔 الآيدي: {u}\n📅 تاريخ التعاقد: {m.get('join_date', 'غير معروف')}\n"
                   f"💰 العمولة المحددة: {m.get('commission', 'غير محددة')}\n\n📊 إحصائيات العملاء للمسوق:\n✅ عملاء تم دفع عمولتهم: {paid_count}\n"
                   f"⏳ عملاء معلقين (اشتركوا بالخاصة ولم يتم الدفع): {pending_vip}\n👀 عملاء معلقين (في العامة فقط): {pending_public}\n\n🔗 رابطه النشط:\n{link}")
            await q.message.edit_text(msg)
        return

    if q.data.startswith("setcomm_"):
        u = q.data.split("_")[1]
        context.user_data['mode'] = f'edit_comm_{u}'
        await q.message.delete()
        await context.bot.send_message(chat_id=ADMIN_ID, text=f"⌨️ أرسل نسبة العمولة الجديدة للمسوق ({data['whitelist'][u]}):\n(مثال: 40% أو 50$)", reply_markup=ReplyKeyboardMarkup([["🔙 رجوع للإدارة"]], resize_keyboard=True))
        return

    if q.data.startswith("burn_"):
        u = q.data.split("_", 1)[1]
        name = data["whitelist"].get(u)
        if not name: return
        old_link = data["active_links"].get(name)
        if old_link:
            try: await context.bot.revoke_chat_invite_link(chat_id=CHANNEL_ID, invite_link=old_link)
            except: pass
        try:
            new_link_obj = await context.bot.create_chat_invite_link(chat_id=CHANNEL_ID, name=name)
            data["active_links"][name] = new_link_obj.invite_link; save_data(data)
            await q.message.edit_text(f"✅ تم الإصدار!\n🔗 الرابط الجديد ({name}):\n{new_link_obj.invite_link}")
            try: await context.bot.send_message(chat_id=int(u), text=f"⚠️ تحديث لرابطك:\nرابطك الجديد هو:\n{new_link_obj.invite_link}")
            except: pass
        except Exception as e: await q.message.edit_text(f"❌ خطأ: {e}")

    if q.data.startswith("kill_"):
        name = q.data.split("_", 1)[1]
        old_link = data["active_links"].get(name)
        if old_link:
            try: await context.bot.revoke_chat_invite_link(chat_id=CHANNEL_ID, invite_link=old_link)
            except: pass
            del data["active_links"][name]; save_data(data)
            await q.message.edit_text(f"✅ تم حرق رابط ({name}) بنجاح.")
        else: await q.message.edit_text("❌ الرابط غير موجود.")

    elif q.data.startswith("pay_"):
        c_id = int(q.data.split("_")[1]); found = False
        for m_name, clients in data["referrals"].items():
            for i, client in enumerate(clients):
                if client['id'] == c_id:
                    client_name = client['n']
                    del data["referrals"][m_name][i]
                    data["paid_count"] = data.get("paid_count", 0) + 1; save_data(data)
                    await q.message.edit_text(f"✅ تمت التصفية! 💸\nالعميل: {client_name}\nرصيد المسوق: {m_name}.")
                    m_id = next((uid for uid, n in data["whitelist"].items() if n == m_name), None)
                    if m_id:
                        try: await context.bot.send_message(chat_id=int(m_id), text=f"💸 استلام عمولة:\nتم قبول طلبك وتحويل عمولة العميل ({client_name}) لك وتم تصفية حسابه. استمر يا بطل! 🚀")
                        except: pass
                    found = True; break
            if found: break
        if not found: await q.message.edit_text("⚠️ العميل غير موجود أو تم دفع عمولته مسبقاً.")

    elif q.data.startswith("rep_"):
        n = q.data.split("_")[1]
        refs_vip = data["referrals"].get(n, []); refs_pub = data["public_leads"].get(n, [])
        msg = f"📊 كشف حساب ({n})\n\n🟢 معلقين اشتركوا بالخاصة (مستحقين): {len(refs_vip)}\n"
        msg += "\n".join([f"👤 {r['n']} | @{r.get('username', 'لا يوجد')} | {r['d']}" for r in refs_vip]) if refs_vip else "لا يوجد."
        msg += f"\n\n🟡 معلقين في العامة فقط (لم يشتركوا بالخاصة): {len(refs_pub)}\n"
        msg += "\n".join([f"👤 {r['n']} | @{r.get('username', 'لا يوجد')} | {r['d']}" for r in refs_pub]) if refs_pub else "لا يوجد."
        await q.message.reply_text(msg)
    
    elif q.data.startswith("del_"):
        u = q.data.split("_")[1]
        if u in data["whitelist"]:
            name = data["whitelist"][u]; del data["whitelist"][u]; save_data(data)
            try: await context.bot.send_message(chat_id=int(u), text=f"⚠️ تنبيه إداري:\nعذراً ({name})، تم إيقاف حسابك كمسوق وسحب صلاحيات الدخول.")
            except: pass
            await q.edit_message_text(f"✅ تم سحب صلاحية ({name}) بنجاح.")

# --- 🚀 رسالة /start الاحترافية ---
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = str(update.effective_user.id)
    data = load_data()
    
    def get_marketer_keyboard():
        return ReplyKeyboardMarkup([[KeyboardButton("💰 رصيدي الحالي"), KeyboardButton("🔗 رابطي التسويقي")],
                                    [KeyboardButton("💸 طلب سحب الأرباح")], [KeyboardButton("🔙 خروج")]], resize_keyboard=True)

    if user_id in data["whitelist"]:
        name = data["whitelist"][user_id]
        link = data["active_links"].get(name, "لم يتم توليد رابط بعد.")
        count = len(data["referrals"].get(name, []))
        comm = data["marketers_data"].get(user_id, {}).get("commission", "غير محددة")
        comm_text = f"\n💰 العمولة المعتمدة لك: {comm}\n" if comm != "غير محددة" else ""
        
        msg = (f"أهلاً بك يا شريك النجاح ({name}) في اللوحة التنفيذية! 👑\n\nنحن سعداء بوجودك ضمن نخبة مسوقي البروفيسور.\n{comm_text}\n"
               f"🔗 رابط التسويق الخاص بك (VIP):\n{link}\n\n📊 حصاد أرباحك المعلقة:\n👥 لديك: ({count}) عملاء مستحقين لم يتم استلام عمولتهم.\n\n🚀 استمر في التألق! 💸")
        await update.message.reply_text(msg, reply_markup=get_marketer_keyboard())
    else:
        await update.message.reply_text("👋 أهلاً بك في نظام التسويق الخاص بالبروفيسور.", reply_markup=get_main_keyboard(update.effective_user.id))

def main():
    application = Application.builder().token(TOKEN).build()
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CallbackQueryHandler(callback_handler))
    application.add_handler(MessageHandler(filters.ALL & ~filters.COMMAND, master_handler))
    application.add_handler(ChatMemberHandler(track_joins, ChatMemberHandler.CHAT_MEMBER))
    
    print("🚀 Professor CRM Bot (V-Pro VIP Anti-Fraud Edition) Running...")
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__": main()